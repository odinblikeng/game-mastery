(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/packages/app/src/components/AreaReferenceList.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AreaReferenceList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/useGameStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function AreaReferenceList(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(36);
    if ($[0] !== "2025d90db8e9907823a3a8a36d258435070ca671f7b6d494a58335efd5fcf5b5") {
        for(let $i = 0; $i < 36; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "2025d90db8e9907823a3a8a36d258435070ca671f7b6d494a58335efd5fcf5b5";
    }
    const { title, slugs, type } = t0;
    const monsterDataMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_AreaReferenceListUseGameStore);
    const treasureDataMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_AreaReferenceListUseGameStore2);
    const openStatBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_AreaReferenceListUseGameStore3);
    const openTreasure = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_AreaReferenceListUseGameStore4);
    const isMonster = type === "monster";
    const dataMap = isMonster ? monsterDataMap : treasureDataMap;
    const handleClick = isMonster ? openStatBlock : openTreasure;
    const testIdPrefix = isMonster ? "cy-area-monster" : "cy-area-treasure";
    let T0;
    let T1;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    if ($[1] !== dataMap || $[2] !== handleClick || $[3] !== slugs || $[4] !== testIdPrefix || $[5] !== title) {
        t8 = Symbol.for("react.early_return_sentinel");
        bb0: {
            let t9;
            if ($[16] !== dataMap) {
                t9 = ({
                    "AreaReferenceList[slugs.filter()]": (slug)=>Boolean(dataMap[slug])
                })["AreaReferenceList[slugs.filter()]"];
                $[16] = dataMap;
                $[17] = t9;
            } else {
                t9 = $[17];
            }
            const validSlugs = slugs.filter(t9);
            if (validSlugs.length === 0) {
                t8 = null;
                break bb0;
            }
            T1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
            t6 = 1;
            if ($[18] !== title) {
                t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "overline",
                    color: "text.secondary",
                    children: title
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/AreaReferenceList.tsx",
                    lineNumber: 65,
                    columnNumber: 14
                }, this);
                $[18] = title;
                $[19] = t7;
            } else {
                t7 = $[19];
            }
            T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
            t1 = "row";
            t2 = 1;
            t3 = true;
            t4 = "wrap";
            let t10;
            if ($[20] !== dataMap || $[21] !== handleClick || $[22] !== testIdPrefix) {
                t10 = ({
                    "AreaReferenceList[validSlugs.map()]": (slug_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "outlined",
                            size: "small",
                            onClick: {
                                "AreaReferenceList[validSlugs.map() > <Button>.onClick]": ()=>handleClick(slug_0)
                            }["AreaReferenceList[validSlugs.map() > <Button>.onClick]"],
                            "data-testid": `${testIdPrefix}-${slug_0}`,
                            children: dataMap[slug_0].name
                        }, slug_0, false, {
                            fileName: "[project]/packages/app/src/components/AreaReferenceList.tsx",
                            lineNumber: 79,
                            columnNumber: 60
                        }, this)
                })["AreaReferenceList[validSlugs.map()]"];
                $[20] = dataMap;
                $[21] = handleClick;
                $[22] = testIdPrefix;
                $[23] = t10;
            } else {
                t10 = $[23];
            }
            t5 = validSlugs.map(t10);
        }
        $[1] = dataMap;
        $[2] = handleClick;
        $[3] = slugs;
        $[4] = testIdPrefix;
        $[5] = title;
        $[6] = T0;
        $[7] = T1;
        $[8] = t1;
        $[9] = t2;
        $[10] = t3;
        $[11] = t4;
        $[12] = t5;
        $[13] = t6;
        $[14] = t7;
        $[15] = t8;
    } else {
        T0 = $[6];
        T1 = $[7];
        t1 = $[8];
        t2 = $[9];
        t3 = $[10];
        t4 = $[11];
        t5 = $[12];
        t6 = $[13];
        t7 = $[14];
        t8 = $[15];
    }
    if (t8 !== Symbol.for("react.early_return_sentinel")) {
        return t8;
    }
    let t9;
    if ($[24] !== T0 || $[25] !== t1 || $[26] !== t2 || $[27] !== t3 || $[28] !== t4 || $[29] !== t5) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            direction: t1,
            spacing: t2,
            useFlexGap: t3,
            flexWrap: t4,
            children: t5
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AreaReferenceList.tsx",
            lineNumber: 124,
            columnNumber: 10
        }, this);
        $[24] = T0;
        $[25] = t1;
        $[26] = t2;
        $[27] = t3;
        $[28] = t4;
        $[29] = t5;
        $[30] = t9;
    } else {
        t9 = $[30];
    }
    let t10;
    if ($[31] !== T1 || $[32] !== t6 || $[33] !== t7 || $[34] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T1, {
            spacing: t6,
            children: [
                t7,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/AreaReferenceList.tsx",
            lineNumber: 137,
            columnNumber: 11
        }, this);
        $[31] = T1;
        $[32] = t6;
        $[33] = t7;
        $[34] = t9;
        $[35] = t10;
    } else {
        t10 = $[35];
    }
    return t10;
}
_s(AreaReferenceList, "rFkAp/YKmsblQqv7mEjMa/w6KSo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"]
    ];
});
_c = AreaReferenceList;
function _AreaReferenceListUseGameStore4(s_2) {
    return s_2.openTreasure;
}
function _AreaReferenceListUseGameStore3(s_1) {
    return s_1.openStatBlock;
}
function _AreaReferenceListUseGameStore2(s_0) {
    return s_0.treasureDataMap;
}
function _AreaReferenceListUseGameStore(s) {
    return s.monsterDataMap;
}
var _c;
__turbopack_context__.k.register(_c, "AreaReferenceList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/ActionCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActionCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$IconCircle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/IconCircle.tsx [app-client] (ecmascript)");
;
;
;
;
;
function ActionCard(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(15);
    if ($[0] !== "f43798b7bf9c28d98ad304a2c9bdf524eabae897abae619d4b98655833743bec") {
        for(let $i = 0; $i < 15; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f43798b7bf9c28d98ad304a2c9bdf524eabae897abae619d4b98655833743bec";
    }
    const { icon: Icon, label, description } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            p: "20px",
            borderRadius: "12px",
            border: "1px solid",
            borderColor: "divider",
            backgroundColor: "background.paper",
            boxShadow: _temp,
            display: "flex",
            flexDirection: "column",
            gap: 1,
            transition: "transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease",
            "&:hover": {
                transform: "translateY(-1px)",
                boxShadow: _temp2,
                borderColor: _temp3
            }
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            fontSize: 20,
            color: "primary.main"
        };
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    let t3;
    if ($[3] !== Icon) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$IconCircle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: 40,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                sx: t2
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/ActionCard.tsx",
                lineNumber: 59,
                columnNumber: 32
            }, this)
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/ActionCard.tsx",
            lineNumber: 59,
            columnNumber: 10
        }, this);
        $[3] = Icon;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            fontWeight: 600,
            mt: 0.5
        };
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] !== label) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            sx: t4,
            children: label
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/ActionCard.tsx",
            lineNumber: 77,
            columnNumber: 10
        }, this);
        $[6] = label;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            fontSize: "0.8rem",
            lineHeight: 1.4
        };
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] !== description) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            color: "text.secondary",
            sx: t6,
            children: description
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/ActionCard.tsx",
            lineNumber: 95,
            columnNumber: 10
        }, this);
        $[9] = description;
        $[10] = t7;
    } else {
        t7 = $[10];
    }
    let t8;
    if ($[11] !== t3 || $[12] !== t5 || $[13] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t1,
            children: [
                t3,
                t5,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/ActionCard.tsx",
            lineNumber: 103,
            columnNumber: 10
        }, this);
        $[11] = t3;
        $[12] = t5;
        $[13] = t7;
        $[14] = t8;
    } else {
        t8 = $[14];
    }
    return t8;
}
_c = ActionCard;
function _temp3(t_1) {
    return t_1.palette.mode === "dark" ? "rgba(143,140,255,0.35)" : "divider";
}
function _temp2(t_0) {
    return t_0.palette.mode === "dark" ? "0 6px 18px rgba(0,0,0,0.55)" : "0 6px 18px rgba(0,0,0,0.08)";
}
function _temp(t) {
    return t.palette.chrome.shadow;
}
var _c;
__turbopack_context__.k.register(_c, "ActionCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/HeroActionCards.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeroActionCards
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ConstructionRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ConstructionRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MenuBookRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/MenuBookRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$ActionCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/ActionCard.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
function HeroActionCards() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "09784fcf565ca0e7d9df1facd4620c52552fb86a890dd9597ffc4004bd6eddb3") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "09784fcf565ca0e7d9df1facd4620c52552fb86a890dd9597ffc4004bd6eddb3";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: 1.5,
                pt: 1
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$ActionCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MenuBookRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                    label: "Browse Areas",
                    description: "Load area notes, maps, and encounter details."
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/HeroActionCards.tsx",
                    lineNumber: 23,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$ActionCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ConstructionRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                    label: "Session Tools",
                    description: "Track initiative, HP, and turn order."
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/HeroActionCards.tsx",
                    lineNumber: 23,
                    columnNumber: 130
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/HeroActionCards.tsx",
            lineNumber: 18,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    return t0;
}
_c = HeroActionCards;
var _c;
__turbopack_context__.k.register(_c, "HeroActionCards");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=packages_app_src_components_07~f_c.._.js.map