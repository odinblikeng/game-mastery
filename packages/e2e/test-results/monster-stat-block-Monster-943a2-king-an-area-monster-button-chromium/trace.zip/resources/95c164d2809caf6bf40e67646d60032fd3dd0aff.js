(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0bg3nie._.css","static/chunks/packages_app_src_05epz.u._.js","static/chunks/node_modules_next_0btosau._.js","static/chunks/node_modules_@mui_system_esm_0247t0h._.js","static/chunks/node_modules_@mui_material_esm_styles_0j9c5wj._.js","static/chunks/node_modules_@mui_material_esm_09ctq_s._.js","static/chunks/node_modules_@dnd-kit_core_dist_core_esm_0avyu8m.js","static/chunks/node_modules_@popperjs_core_lib_0zj0l6r._.js","static/chunks/node_modules_02rhitl._.js"],
    source: "dynamic"
});
