(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/packages/app/src/components/MonsterStatBlock.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MonsterStatBlock
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Table/Table.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableBody$2f$TableBody$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TableBody/TableBody.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TableCell/TableCell.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableHead$2f$TableHead$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TableHead/TableHead.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TableRow/TableRow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
const abilityOrder = [
    "STR",
    "DEX",
    "CON",
    "INT",
    "WIS",
    "CHA"
];
function formatModifier(modifier) {
    return modifier >= 0 ? `+${modifier}` : `${modifier}`;
}
function formatList(values) {
    return values?.length ? values.join(", ") : null;
}
function TraitSection(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    if ($[0] !== "52eea5cce63c7dca743def794b49816dde5a3e40f3c1e52b5cfec153e457badc") {
        for(let $i = 0; $i < 13; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "52eea5cce63c7dca743def794b49816dde5a3e40f3c1e52b5cfec153e457badc";
    }
    const { title, items } = t0;
    if (!items?.length) {
        return null;
    }
    let t1;
    if ($[1] !== title) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h6",
            children: title
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 44,
            columnNumber: 10
        }, this);
        $[1] = title;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== items || $[4] !== title) {
        let t3;
        if ($[6] !== title) {
            t3 = ({
                "TraitSection[items.map()]": (item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            component: "p",
                            variant: "body2",
                            sx: {
                                lineHeight: 1.7
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    component: "span",
                                    sx: {
                                        fontWeight: 700
                                    },
                                    children: [
                                        item.name,
                                        "."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
                                    lineNumber: 57,
                                    columnNumber: 14
                                }, this),
                                item.description
                            ]
                        }, void 0, true, {
                            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
                            lineNumber: 55,
                            columnNumber: 81
                        }, this)
                    }, `${title}-${item.name}`, false, {
                        fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
                        lineNumber: 55,
                        columnNumber: 46
                    }, this)
            })["TraitSection[items.map()]"];
            $[6] = title;
            $[7] = t3;
        } else {
            t3 = $[7];
        }
        t2 = items.map(t3);
        $[3] = items;
        $[4] = title;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    let t3;
    if ($[8] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            spacing: 1.25,
            children: t2
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 75,
            columnNumber: 10
        }, this);
        $[8] = t2;
        $[9] = t3;
    } else {
        t3 = $[9];
    }
    let t4;
    if ($[10] !== t1 || $[11] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            spacing: 1,
            children: [
                t1,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 83,
            columnNumber: 10
        }, this);
        $[10] = t1;
        $[11] = t3;
        $[12] = t4;
    } else {
        t4 = $[12];
    }
    return t4;
}
_c = TraitSection;
function MonsterStatBlock(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(83);
    if ($[0] !== "52eea5cce63c7dca743def794b49816dde5a3e40f3c1e52b5cfec153e457badc") {
        for(let $i = 0; $i < 83; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "52eea5cce63c7dca743def794b49816dde5a3e40f3c1e52b5cfec153e457badc";
    }
    const { monster } = t0;
    const armorClassLabel = monster.armorClass.type ? `${monster.armorClass.value} (${monster.armorClass.type})` : `${monster.armorClass.value}`;
    const hitPointsLabel = monster.hitPoints.formula ? `${monster.hitPoints.value} (${monster.hitPoints.formula})` : `${monster.hitPoints.value}`;
    let t1;
    if ($[1] !== monster.speed) {
        t1 = Object.entries(monster.speed).map(_MonsterStatBlockAnonymous);
        $[1] = monster.speed;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const speedLabel = t1.join(", ");
    let t2;
    if ($[3] !== monster.senses) {
        t2 = {
            label: "Senses",
            value: monster.senses
        };
        $[3] = monster.senses;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    if ($[5] !== monster.languages) {
        t3 = {
            label: "Languages",
            value: monster.languages
        };
        $[5] = monster.languages;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const t4 = monster.challenge ? `${monster.challenge.rating} (${monster.challenge.xp} XP)` : undefined;
    let t5;
    if ($[7] !== t4) {
        t5 = {
            label: "Challenge",
            value: t4
        };
        $[7] = t4;
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[9] !== monster.proficiencyBonus) {
        t6 = monster.proficiencyBonus != null ? formatModifier(monster.proficiencyBonus) : undefined;
        $[9] = monster.proficiencyBonus;
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    let t7;
    if ($[11] !== t6) {
        t7 = {
            label: "Proficiency Bonus",
            value: t6
        };
        $[11] = t6;
        $[12] = t7;
    } else {
        t7 = $[12];
    }
    let t8;
    if ($[13] !== monster.damageVulnerabilities) {
        t8 = formatList(monster.damageVulnerabilities) ?? undefined;
        $[13] = monster.damageVulnerabilities;
        $[14] = t8;
    } else {
        t8 = $[14];
    }
    let t9;
    if ($[15] !== t8) {
        t9 = {
            label: "Damage Vulnerabilities",
            value: t8
        };
        $[15] = t8;
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    let t10;
    if ($[17] !== monster.damageResistances) {
        t10 = formatList(monster.damageResistances) ?? undefined;
        $[17] = monster.damageResistances;
        $[18] = t10;
    } else {
        t10 = $[18];
    }
    let t11;
    if ($[19] !== t10) {
        t11 = {
            label: "Damage Resistances",
            value: t10
        };
        $[19] = t10;
        $[20] = t11;
    } else {
        t11 = $[20];
    }
    let t12;
    if ($[21] !== monster.damageImmunities) {
        t12 = formatList(monster.damageImmunities) ?? undefined;
        $[21] = monster.damageImmunities;
        $[22] = t12;
    } else {
        t12 = $[22];
    }
    let t13;
    if ($[23] !== t12) {
        t13 = {
            label: "Damage Immunities",
            value: t12
        };
        $[23] = t12;
        $[24] = t13;
    } else {
        t13 = $[24];
    }
    let t14;
    if ($[25] !== monster.conditionImmunities) {
        t14 = formatList(monster.conditionImmunities) ?? undefined;
        $[25] = monster.conditionImmunities;
        $[26] = t14;
    } else {
        t14 = $[26];
    }
    let t15;
    if ($[27] !== t14) {
        t15 = {
            label: "Condition Immunities",
            value: t14
        };
        $[27] = t14;
        $[28] = t15;
    } else {
        t15 = $[28];
    }
    let t16;
    if ($[29] !== t11 || $[30] !== t13 || $[31] !== t15 || $[32] !== t2 || $[33] !== t3 || $[34] !== t5 || $[35] !== t7 || $[36] !== t9) {
        t16 = [
            t2,
            t3,
            t5,
            t7,
            t9,
            t11,
            t13,
            t15
        ].filter(_MonsterStatBlockAnonymous2);
        $[29] = t11;
        $[30] = t13;
        $[31] = t15;
        $[32] = t2;
        $[33] = t3;
        $[34] = t5;
        $[35] = t7;
        $[36] = t9;
        $[37] = t16;
    } else {
        t16 = $[37];
    }
    const details = t16;
    let t17;
    if ($[38] !== monster.image || $[39] !== monster.name) {
        t17 = monster.image ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            component: "img",
            src: monster.image,
            alt: monster.name,
            sx: {
                width: "100%",
                maxHeight: 260,
                objectFit: "contain",
                borderRadius: 2,
                border: 1,
                borderColor: "divider",
                bgcolor: "background.paper"
            }
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 261,
            columnNumber: 27
        }, this) : null;
        $[38] = monster.image;
        $[39] = monster.name;
        $[40] = t17;
    } else {
        t17 = $[40];
    }
    let t18;
    if ($[41] !== monster.name) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h4",
            children: monster.name
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 278,
            columnNumber: 11
        }, this);
        $[41] = monster.name;
        $[42] = t18;
    } else {
        t18 = $[42];
    }
    let t19;
    if ($[43] !== monster.size || $[44] !== monster.type) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "subtitle1",
            color: "text.secondary",
            children: [
                monster.size,
                " ",
                monster.type
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 286,
            columnNumber: 11
        }, this);
        $[43] = monster.size;
        $[44] = monster.type;
        $[45] = t19;
    } else {
        t19 = $[45];
    }
    const t20 = `AC ${armorClassLabel}`;
    let t21;
    if ($[46] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: t20,
            color: "primary",
            variant: "outlined"
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 296,
            columnNumber: 11
        }, this);
        $[46] = t20;
        $[47] = t21;
    } else {
        t21 = $[47];
    }
    const t22 = `HP ${hitPointsLabel}`;
    let t23;
    if ($[48] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: t22,
            color: "secondary",
            variant: "outlined"
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 305,
            columnNumber: 11
        }, this);
        $[48] = t22;
        $[49] = t23;
    } else {
        t23 = $[49];
    }
    const t24 = `Speed ${speedLabel}`;
    let t25;
    if ($[50] !== t24) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: t24,
            variant: "outlined"
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 314,
            columnNumber: 11
        }, this);
        $[50] = t24;
        $[51] = t25;
    } else {
        t25 = $[51];
    }
    let t26;
    if ($[52] !== t21 || $[53] !== t23 || $[54] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "row",
            spacing: 1,
            useFlexGap: true,
            flexWrap: "wrap",
            children: [
                t21,
                t23,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 322,
            columnNumber: 11
        }, this);
        $[52] = t21;
        $[53] = t23;
        $[54] = t25;
        $[55] = t26;
    } else {
        t26 = $[55];
    }
    let t27;
    if ($[56] !== t18 || $[57] !== t19 || $[58] !== t26) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            spacing: 1,
            children: [
                t18,
                t19,
                t26
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 332,
            columnNumber: 11
        }, this);
        $[56] = t18;
        $[57] = t19;
        $[58] = t26;
        $[59] = t27;
    } else {
        t27 = $[59];
    }
    let t28;
    if ($[60] === Symbol.for("react.memo_cache_sentinel")) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 342,
            columnNumber: 11
        }, this);
        $[60] = t28;
    } else {
        t28 = $[60];
    }
    let t29;
    if ($[61] === Symbol.for("react.memo_cache_sentinel")) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "h6",
            children: "Ability Scores"
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 349,
            columnNumber: 11
        }, this);
        $[61] = t29;
    } else {
        t29 = $[61];
    }
    const t30 = `${monster.name} ability scores`;
    let t31;
    if ($[62] === Symbol.for("react.memo_cache_sentinel")) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableHead$2f$TableHead$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: abilityOrder.map(_MonsterStatBlockAbilityOrderMap)
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
                lineNumber: 357,
                columnNumber: 22
            }, this)
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 357,
            columnNumber: 11
        }, this);
        $[62] = t31;
    } else {
        t31 = $[62];
    }
    let t32;
    if ($[63] !== monster.abilityScores) {
        t32 = abilityOrder.map({
            "MonsterStatBlock[abilityOrder.map()]": (ability_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    align: "center",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        spacing: 0.25,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                fontWeight: 700,
                                children: monster.abilityScores[ability_0].score
                            }, void 0, false, {
                                fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
                                lineNumber: 365,
                                columnNumber: 124
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: "caption",
                                color: "text.secondary",
                                children: formatModifier(monster.abilityScores[ability_0].modifier)
                            }, void 0, false, {
                                fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
                                lineNumber: 365,
                                columnNumber: 206
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
                        lineNumber: 365,
                        columnNumber: 102
                    }, this)
                }, ability_0, false, {
                    fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
                    lineNumber: 365,
                    columnNumber: 60
                }, this)
        }["MonsterStatBlock[abilityOrder.map()]"]);
        $[63] = monster.abilityScores;
        $[64] = t32;
    } else {
        t32 = $[64];
    }
    let t33;
    if ($[65] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableBody$2f$TableBody$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableRow$2f$TableRow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: t32
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
                lineNumber: 374,
                columnNumber: 22
            }, this)
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 374,
            columnNumber: 11
        }, this);
        $[65] = t32;
        $[66] = t33;
    } else {
        t33 = $[66];
    }
    let t34;
    if ($[67] !== t30 || $[68] !== t33) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            spacing: 1.5,
            children: [
                t29,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Table$2f$Table$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    size: "small",
                    "aria-label": t30,
                    children: [
                        t31,
                        t33
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
                    lineNumber: 382,
                    columnNumber: 37
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 382,
            columnNumber: 11
        }, this);
        $[67] = t30;
        $[68] = t33;
        $[69] = t34;
    } else {
        t34 = $[69];
    }
    let t35;
    if ($[70] !== details) {
        t35 = details.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
                    lineNumber: 391,
                    columnNumber: 30
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    spacing: 1,
                    children: details.map(_MonsterStatBlockDetailsMap)
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
                    lineNumber: 391,
                    columnNumber: 41
                }, this)
            ]
        }, void 0, true) : null;
        $[70] = details;
        $[71] = t35;
    } else {
        t35 = $[71];
    }
    let t36;
    if ($[72] !== monster.traits) {
        t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TraitSection, {
            title: "Abilities",
            items: monster.traits
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 399,
            columnNumber: 11
        }, this);
        $[72] = monster.traits;
        $[73] = t36;
    } else {
        t36 = $[73];
    }
    let t37;
    if ($[74] !== monster.actions) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TraitSection, {
            title: "Actions",
            items: monster.actions
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 407,
            columnNumber: 11
        }, this);
        $[74] = monster.actions;
        $[75] = t37;
    } else {
        t37 = $[75];
    }
    let t38;
    if ($[76] !== t17 || $[77] !== t27 || $[78] !== t34 || $[79] !== t35 || $[80] !== t36 || $[81] !== t37) {
        t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            spacing: 3,
            children: [
                t17,
                t27,
                t28,
                t34,
                t35,
                t36,
                t37
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
            lineNumber: 415,
            columnNumber: 11
        }, this);
        $[76] = t17;
        $[77] = t27;
        $[78] = t34;
        $[79] = t35;
        $[80] = t36;
        $[81] = t37;
        $[82] = t38;
    } else {
        t38 = $[82];
    }
    return t38;
}
_c1 = MonsterStatBlock;
function _MonsterStatBlockDetailsMap(detail_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        variant: "body2",
        sx: {
            lineHeight: 1.7
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                component: "span",
                sx: {
                    fontWeight: 700
                },
                children: [
                    detail_0.label,
                    "."
                ]
            }, void 0, true, {
                fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
                lineNumber: 431,
                columnNumber: 6
            }, this),
            detail_0.value
        ]
    }, detail_0.label, true, {
        fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
        lineNumber: 429,
        columnNumber: 10
    }, this);
}
function _MonsterStatBlockAbilityOrderMap(ability) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TableCell$2f$TableCell$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        align: "center",
        sx: {
            fontWeight: 700
        },
        children: ability
    }, ability, false, {
        fileName: "[project]/packages/app/src/components/MonsterStatBlock.tsx",
        lineNumber: 436,
        columnNumber: 10
    }, this);
}
function _MonsterStatBlockAnonymous2(detail) {
    return Boolean(detail.value);
}
function _MonsterStatBlockAnonymous(t0) {
    const [type, value] = t0;
    return `${type} ${value}`;
}
var _c, _c1;
__turbopack_context__.k.register(_c, "TraitSection");
__turbopack_context__.k.register(_c1, "MonsterStatBlock");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/OverlayDialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OverlayDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloseRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CloseRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Dialog/Dialog.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogActions/DialogActions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogContent/DialogContent.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/DialogTitle/DialogTitle.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
function OverlayDialog(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(21);
    if ($[0] !== "b7fa7a1166b24d5d9f2082377b14093a03ed16bc0ef6ff14a0d4d7eabc9e75c5") {
        for(let $i = 0; $i < 21; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b7fa7a1166b24d5d9f2082377b14093a03ed16bc0ef6ff14a0d4d7eabc9e75c5";
    }
    const { open, onClose, title, children, actions, maxWidth: t1, testId } = t0;
    const maxWidth = t1 === undefined ? "md" : t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            pr: 7
        };
        $[1] = t2;
    } else {
        t2 = $[1];
    }
    let t3;
    if ($[2] !== title) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogTitle$2f$DialogTitle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t2,
            children: title
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/OverlayDialog.tsx",
            lineNumber: 48,
            columnNumber: 10
        }, this);
        $[2] = title;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    let t4;
    let t5;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            position: "absolute",
            top: 12,
            right: 12
        };
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloseRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/packages/app/src/components/OverlayDialog.tsx",
            lineNumber: 62,
            columnNumber: 10
        }, this);
        $[4] = t4;
        $[5] = t5;
    } else {
        t4 = $[4];
        t5 = $[5];
    }
    let t6;
    if ($[6] !== onClose) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            "aria-label": "Close dialog",
            onClick: onClose,
            sx: t4,
            children: t5
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/OverlayDialog.tsx",
            lineNumber: 71,
            columnNumber: 10
        }, this);
        $[6] = onClose;
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] !== children) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogContent$2f$DialogContent$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            dividers: true,
            children: children
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/OverlayDialog.tsx",
            lineNumber: 79,
            columnNumber: 10
        }, this);
        $[8] = children;
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    let t8;
    if ($[10] !== actions) {
        t8 = actions ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$DialogActions$2f$DialogActions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: actions
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/OverlayDialog.tsx",
            lineNumber: 87,
            columnNumber: 20
        }, this) : null;
        $[10] = actions;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    let t9;
    if ($[12] !== maxWidth || $[13] !== onClose || $[14] !== open || $[15] !== t3 || $[16] !== t6 || $[17] !== t7 || $[18] !== t8 || $[19] !== testId) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Dialog$2f$Dialog$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: open,
            onClose: onClose,
            fullWidth: true,
            maxWidth: maxWidth,
            "data-testid": testId,
            children: [
                t3,
                t6,
                t7,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/OverlayDialog.tsx",
            lineNumber: 95,
            columnNumber: 10
        }, this);
        $[12] = maxWidth;
        $[13] = onClose;
        $[14] = open;
        $[15] = t3;
        $[16] = t6;
        $[17] = t7;
        $[18] = t8;
        $[19] = testId;
        $[20] = t9;
    } else {
        t9 = $[20];
    }
    return t9;
}
_c = OverlayDialog;
var _c;
__turbopack_context__.k.register(_c, "OverlayDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/lib/initiative.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatTime",
    ()=>formatTime,
    "isCharDead",
    ()=>isCharDead,
    "renumberMonsterCopies",
    ()=>renumberMonsterCopies,
    "toTestId",
    ()=>toTestId
]);
const toTestId = (value)=>value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
const renumberMonsterCopies = (items, monsterNameBySlug)=>{
    const totals = new Map();
    for (const item of items){
        if (!item.monsterSlug) {
            continue;
        }
        totals.set(item.monsterSlug, (totals.get(item.monsterSlug) ?? 0) + 1);
    }
    const seen = new Map();
    return items.map((item)=>{
        if (!item.monsterSlug) {
            return item;
        }
        const total = totals.get(item.monsterSlug) ?? 0;
        const baseName = monsterNameBySlug.get(item.monsterSlug) ?? item.name.replace(/ \d+$/, "");
        const index = (seen.get(item.monsterSlug) ?? 0) + 1;
        const nextName = total > 1 ? `${baseName} ${index}` : baseName;
        const nextCopyIndex = total > 1 ? index : undefined;
        seen.set(item.monsterSlug, index);
        return item.name === nextName && item.copyIndex === nextCopyIndex ? item : {
            ...item,
            name: nextName,
            copyIndex: nextCopyIndex
        };
    });
};
const isCharDead = (c)=>typeof c.maxHp === "number" ? (c.hp ?? c.maxHp) <= 0 : c.dying && c.failures >= 3;
const formatTime = (turns)=>{
    const seconds = turns * 6;
    if (seconds < 60) return `${seconds}s`;
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return s > 0 ? `${m}m ${s}s` : `${m}m`;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/store/urlSync.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * URL sync utility for the Zustand store.
 *
 * The store is the source of truth for UI state at runtime. This module
 * provides helpers to:
 *   1. Build the canonical URL from the current store UI state.
 *   2. Push the canonical URL to the browser address bar.
 *   3. Read the initial URL params on first hydration to seed the store.
 *
 * Deliberately kept free of React hooks so it can be used in Zustand
 * actions and subscriber callbacks.
 */ __turbopack_context__.s([
    "buildUrlFromState",
    ()=>buildUrlFromState,
    "pushUrlFromState",
    ()=>pushUrlFromState,
    "readInitialUrlState",
    ()=>readInitialUrlState
]);
function buildUrlFromState(state) {
    const params = new URLSearchParams();
    if (state.areaSidebarOpen) {
        params.set("sidebar", "areas");
    }
    if (state.selectedAreaSlug) {
        params.set("area", state.selectedAreaSlug);
    }
    if (state.toolsParam) {
        params.set("tools", state.toolsParam);
    }
    const query = params.toString();
    return query ? `/?${query}` : "/";
}
function pushUrlFromState(state) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const url = buildUrlFromState(state);
    window.history.pushState({}, "", url);
}
function readInitialUrlState() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const params = new URLSearchParams(window.location.search);
    const sidebar = params.get("sidebar");
    const area = params.get("area");
    const tools = params.get("tools");
    return {
        areaSidebarOpen: sidebar === "areas" || Boolean(area),
        selectedAreaSlug: area ?? null,
        toolsParam: tools ?? null
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/store/useGameStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "selectInitiative",
    ()=>selectInitiative,
    "selectMonsterDataMap",
    ()=>selectMonsterDataMap,
    "selectMonsters",
    ()=>selectMonsters,
    "selectUI",
    ()=>selectUI,
    "useGameStore",
    ()=>useGameStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dnd-kit/sortable/dist/sortable.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/lib/initiative.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$urlSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/urlSync.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
// Module-scoped ID counter — safe to use outside React render.
let idCounter = 0;
function nextId() {
    idCounter += 1;
    return `char-${idCounter}`;
}
const useGameStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
        // -------------------------------------------------------------------------
        // Static data
        // -------------------------------------------------------------------------
        monsters: [],
        monsterDataMap: {},
        treasures: [],
        treasureDataMap: {},
        registerStaticData (monsters, monsterDataMap, treasures, treasureDataMap) {
            set({
                monsters,
                monsterDataMap,
                treasures,
                treasureDataMap
            });
        },
        // -------------------------------------------------------------------------
        // Initiative
        // -------------------------------------------------------------------------
        characters: [],
        resolved: [],
        isReady: false,
        activeIndex: 0,
        round: 1,
        totalTurns: 0,
        queuedSetupCount: 0,
        addCharacter (name, bonus) {
            const trimmed = name.trim();
            if (!trimmed) return;
            set((state)=>({
                    characters: [
                        ...state.characters,
                        {
                            id: nextId(),
                            name: trimmed,
                            bonus,
                            roll: ""
                        }
                    ]
                }));
        },
        addMonster (slug) {
            const { monsterDataMap, isReady } = get();
            const monster = monsterDataMap[slug];
            if (!monster) return;
            const monsterNameBySlug = new Map(get().monsters.map((m)=>[
                    m.slug,
                    m.name
                ]));
            set((state)=>{
                const newChar = {
                    id: nextId(),
                    name: monster.name,
                    bonus: monster.abilityScores.DEX.modifier,
                    roll: "",
                    maxHp: monster.hitPoints.value,
                    monsterSlug: slug
                };
                if (isReady) {
                    // Already in combat — queue for next reset
                    return {
                        queuedSetupCount: state.queuedSetupCount + 1
                    };
                }
                return {
                    characters: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renumberMonsterCopies"])([
                        ...state.characters,
                        newChar
                    ], monsterNameBySlug)
                };
            });
        },
        updateCharacter (id, field, value) {
            set((state)=>({
                    characters: state.characters.map((c)=>{
                        if (c.id !== id) return c;
                        if (field === "name") return {
                            ...c,
                            name: value
                        };
                        if (field === "bonus") return {
                            ...c,
                            bonus: value === "" ? 0 : Number(value)
                        };
                        return {
                            ...c,
                            roll: value === "" ? "" : Number(value)
                        };
                    })
                }));
        },
        deleteCharacter (id) {
            const { isReady, monsters } = get();
            const monsterNameBySlug = new Map(monsters.map((m)=>[
                    m.slug,
                    m.name
                ]));
            if (isReady) {
                set((state)=>{
                    const next = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renumberMonsterCopies"])(state.resolved.filter((c)=>c.id !== id), monsterNameBySlug);
                    return {
                        resolved: next,
                        activeIndex: next.length === 0 ? 0 : Math.min(state.activeIndex, next.length - 1)
                    };
                });
            } else {
                set((state)=>({
                        characters: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["renumberMonsterCopies"])(state.characters.filter((c)=>c.id !== id), monsterNameBySlug)
                    }));
            }
        },
        ready () {
            const { characters } = get();
            const sorted = characters.map((c)=>({
                    id: c.id,
                    name: c.name,
                    bonus: c.bonus,
                    total: (c.roll === "" ? 0 : c.roll) + c.bonus,
                    dying: false,
                    successes: 0,
                    failures: 0,
                    hp: c.maxHp,
                    maxHp: c.maxHp,
                    monsterSlug: c.monsterSlug,
                    copyIndex: c.copyIndex
                })).sort((a, b)=>{
                if (b.total !== a.total) return b.total - a.total;
                return b.bonus - a.bonus;
            });
            set({
                resolved: sorted,
                isReady: true
            });
        },
        reset () {
            set({
                isReady: false,
                resolved: [],
                characters: [],
                activeIndex: 0,
                round: 1,
                totalTurns: 0,
                queuedSetupCount: 0
            });
        },
        nextTurn () {
            set((state)=>{
                const { resolved, activeIndex, round, totalTurns } = state;
                const len = resolved.length;
                if (len === 0) return {};
                let next = activeIndex;
                let nextRound = round;
                for(let step = 0; step < len; step++){
                    next = next >= len - 1 ? 0 : next + 1;
                    if (next === 0) nextRound += 1;
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCharDead"])(resolved[next])) break;
                }
                return {
                    activeIndex: next,
                    round: nextRound,
                    totalTurns: totalTurns + 1
                };
            });
        },
        previousTurn () {
            set((state)=>{
                const { resolved, activeIndex, round, totalTurns } = state;
                const len = resolved.length;
                if (len === 0) return {};
                let next = activeIndex;
                let nextRound = round;
                for(let step = 0; step < len; step++){
                    next = next <= 0 ? len - 1 : next - 1;
                    if (next === len - 1) nextRound = Math.max(1, nextRound - 1);
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCharDead"])(resolved[next])) break;
                }
                return {
                    activeIndex: next,
                    round: nextRound,
                    totalTurns: Math.max(0, totalTurns - 1)
                };
            });
        },
        toggleDying (id) {
            set((state)=>({
                    resolved: state.resolved.map((c)=>c.id === id && typeof c.maxHp !== "number" ? {
                            ...c,
                            dying: !c.dying,
                            successes: 0,
                            failures: 0
                        } : c)
                }));
        },
        setHp (id, value) {
            set((state)=>({
                    resolved: state.resolved.map((c)=>{
                        if (c.id !== id || typeof c.maxHp !== "number") return c;
                        const next = value === "" ? 0 : Number(value);
                        if (Number.isNaN(next)) return c;
                        return {
                            ...c,
                            hp: Math.max(0, Math.min(c.maxHp, next))
                        };
                    })
                }));
        },
        updateSaves (id, field, delta) {
            set((state)=>({
                    resolved: state.resolved.map((c)=>{
                        if (c.id !== id) return c;
                        const val = Math.max(0, Math.min(3, c[field] + delta));
                        return {
                            ...c,
                            [field]: val
                        };
                    })
                }));
        },
        reorder (activeId, overId) {
            set((state)=>{
                const oldIndex = state.resolved.findIndex((c)=>c.id === activeId);
                const newIndex = state.resolved.findIndex((c)=>c.id === overId);
                if (oldIndex === -1 || newIndex === -1) return {};
                return {
                    resolved: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrayMove"])(state.resolved, oldIndex, newIndex)
                };
            });
        },
        clearQueuedSetupCount () {
            set({
                queuedSetupCount: 0
            });
        },
        // -------------------------------------------------------------------------
        // UI state
        // -------------------------------------------------------------------------
        openMonsterSlug: null,
        openTreasureSlug: null,
        areaSidebarOpen: true,
        selectedAreaSlug: null,
        toolsParam: null,
        colorMode: "system",
        openStatBlock (slug) {
            const { monsterDataMap } = get();
            if (!monsterDataMap[slug]) return;
            set({
                openMonsterSlug: slug
            });
        },
        closeStatBlock () {
            set({
                openMonsterSlug: null
            });
        },
        openTreasure (slug) {
            const { treasureDataMap } = get();
            if (!treasureDataMap[slug]) return;
            set({
                openTreasureSlug: slug
            });
        },
        closeTreasure () {
            set({
                openTreasureSlug: null
            });
        },
        openAreaSidebar () {
            const state = get();
            set({
                areaSidebarOpen: true
            });
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$urlSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushUrlFromState"])({
                areaSidebarOpen: true,
                selectedAreaSlug: state.selectedAreaSlug,
                toolsParam: state.toolsParam
            });
        },
        closeAreaSidebar () {
            set({
                areaSidebarOpen: false
            });
        },
        selectArea (slug) {
            set({
                selectedAreaSlug: slug,
                areaSidebarOpen: true
            });
        },
        setToolsParam (value) {
            const state = get();
            set({
                toolsParam: value
            });
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$urlSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushUrlFromState"])({
                areaSidebarOpen: state.areaSidebarOpen,
                selectedAreaSlug: state.selectedAreaSlug,
                toolsParam: value
            });
        },
        closeTools () {
            const state = get();
            set({
                toolsParam: null
            });
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$urlSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pushUrlFromState"])({
                areaSidebarOpen: state.areaSidebarOpen,
                selectedAreaSlug: state.selectedAreaSlug,
                toolsParam: null
            });
        },
        setColorMode (mode) {
            set({
                colorMode: mode
            });
        }
    }));
const selectMonsters = (s)=>s.monsters;
const selectMonsterDataMap = (s)=>s.monsterDataMap;
const selectInitiative = (s)=>({
        characters: s.characters,
        resolved: s.resolved,
        isReady: s.isReady,
        activeIndex: s.activeIndex,
        round: s.round,
        totalTurns: s.totalTurns,
        queuedSetupCount: s.queuedSetupCount
    });
const selectUI = (s)=>({
        openMonsterSlug: s.openMonsterSlug,
        openTreasureSlug: s.openTreasureSlug,
        areaSidebarOpen: s.areaSidebarOpen,
        selectedAreaSlug: s.selectedAreaSlug,
        toolsParam: s.toolsParam,
        colorMode: s.colorMode
    });
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/MonsterStatBlockDialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MonsterStatBlockDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$MonsterStatBlock$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/MonsterStatBlock.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$OverlayDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/OverlayDialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/useGameStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function MonsterStatBlockDialog() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "00a898ec7132d60b2a32a02b162042aea1ad0daeade184276e1d0e7e2af6020a") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "00a898ec7132d60b2a32a02b162042aea1ad0daeade184276e1d0e7e2af6020a";
    }
    const openMonsterSlug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_MonsterStatBlockDialogUseGameStore);
    const monsterDataMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_MonsterStatBlockDialogUseGameStore2);
    const closeStatBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_MonsterStatBlockDialogUseGameStore3);
    const addMonster = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_MonsterStatBlockDialogUseGameStore4);
    const setToolsParam = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_MonsterStatBlockDialogUseGameStore5);
    const monster = openMonsterSlug ? monsterDataMap[openMonsterSlug] : null;
    let t0;
    if ($[1] !== addMonster || $[2] !== closeStatBlock || $[3] !== openMonsterSlug || $[4] !== setToolsParam) {
        t0 = ({
            "MonsterStatBlockDialog[handleAddToInitiative]": ()=>{
                if (!openMonsterSlug) {
                    return;
                }
                addMonster(openMonsterSlug);
                closeStatBlock();
                setToolsParam("initiative");
            }
        })["MonsterStatBlockDialog[handleAddToInitiative]"];
        $[1] = addMonster;
        $[2] = closeStatBlock;
        $[3] = openMonsterSlug;
        $[4] = setToolsParam;
        $[5] = t0;
    } else {
        t0 = $[5];
    }
    const handleAddToInitiative = t0;
    const t1 = Boolean(monster);
    const t2 = monster?.name ?? "Monster details";
    let t3;
    if ($[6] !== handleAddToInitiative || $[7] !== monster) {
        t3 = monster ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "contained",
            onClick: handleAddToInitiative,
            "data-testid": "cy-monster-add-initiative",
            children: "Add to Initiative"
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlockDialog.tsx",
            lineNumber: 47,
            columnNumber: 20
        }, this) : null;
        $[6] = handleAddToInitiative;
        $[7] = monster;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    let t4;
    if ($[9] !== monster) {
        t4 = monster ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$MonsterStatBlock$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            monster: monster
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlockDialog.tsx",
            lineNumber: 56,
            columnNumber: 20
        }, this) : null;
        $[9] = monster;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    let t5;
    if ($[11] !== closeStatBlock || $[12] !== t1 || $[13] !== t2 || $[14] !== t3 || $[15] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$OverlayDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: t1,
            onClose: closeStatBlock,
            title: t2,
            testId: "cy-monster-stat-dialog",
            actions: t3,
            children: t4
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterStatBlockDialog.tsx",
            lineNumber: 64,
            columnNumber: 10
        }, this);
        $[11] = closeStatBlock;
        $[12] = t1;
        $[13] = t2;
        $[14] = t3;
        $[15] = t4;
        $[16] = t5;
    } else {
        t5 = $[16];
    }
    return t5;
}
_s(MonsterStatBlockDialog, "Ou207ywQ4V+D7bX+0SH4M3H4Hx4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"]
    ];
});
_c = MonsterStatBlockDialog;
function _MonsterStatBlockDialogUseGameStore5(s_3) {
    return s_3.setToolsParam;
}
function _MonsterStatBlockDialogUseGameStore4(s_2) {
    return s_2.addMonster;
}
function _MonsterStatBlockDialogUseGameStore3(s_1) {
    return s_1.closeStatBlock;
}
function _MonsterStatBlockDialogUseGameStore2(s_0) {
    return s_0.monsterDataMap;
}
function _MonsterStatBlockDialogUseGameStore(s) {
    return s.openMonsterSlug;
}
var _c;
__turbopack_context__.k.register(_c, "MonsterStatBlockDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/StoreHydrator.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StoreHydrator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/ThemeProviderWithVars.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/useGameStore.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function StoreHydrator({ monsters, monsterDataMap, treasures, treasureDataMap }) {
    _s();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const { mode } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useColorScheme"])();
    const registerStaticData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])({
        "StoreHydrator.useGameStore[registerStaticData]": (s)=>s.registerStaticData
    }["StoreHydrator.useGameStore[registerStaticData]"]);
    const setColorMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])({
        "StoreHydrator.useGameStore[setColorMode]": (s)=>s.setColorMode
    }["StoreHydrator.useGameStore[setColorMode]"]);
    const openAreaSidebar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])({
        "StoreHydrator.useGameStore[openAreaSidebar]": (s)=>s.openAreaSidebar
    }["StoreHydrator.useGameStore[openAreaSidebar]"]);
    const selectArea = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])({
        "StoreHydrator.useGameStore[selectArea]": (s)=>s.selectArea
    }["StoreHydrator.useGameStore[selectArea]"]);
    const closeAreaSidebar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])({
        "StoreHydrator.useGameStore[closeAreaSidebar]": (s)=>s.closeAreaSidebar
    }["StoreHydrator.useGameStore[closeAreaSidebar]"]);
    const setToolsParam = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])({
        "StoreHydrator.useGameStore[setToolsParam]": (s)=>s.setToolsParam
    }["StoreHydrator.useGameStore[setToolsParam]"]);
    // Register static data on mount — runs once per page session.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StoreHydrator.useEffect": ()=>{
            registerStaticData(monsters, monsterDataMap, treasures, treasureDataMap);
        }
    }["StoreHydrator.useEffect"], [
        monsters,
        monsterDataMap,
        treasures,
        treasureDataMap,
        registerStaticData
    ]);
    // Sync area sidebar and selected area from URL on every Next.js navigation.
    // Area content is server-rendered by page.tsx based on URL searchParams,
    // so area selection always goes through Next.js router.push (Link clicks).
    // This effect keeps the store in sync with those URL-driven navigations.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StoreHydrator.useEffect": ()=>{
            const sidebar = searchParams.get("sidebar");
            const area = searchParams.get("area");
            const store = __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"].getState();
            const nextAreaSidebarOpen = sidebar === "areas" || Boolean(area);
            const nextSelectedAreaSlug = area ?? null;
            if (nextSelectedAreaSlug && store.selectedAreaSlug !== nextSelectedAreaSlug) {
                selectArea(nextSelectedAreaSlug);
            } else if (!nextSelectedAreaSlug && nextAreaSidebarOpen && !store.areaSidebarOpen) {
                openAreaSidebar();
            } else if (!nextAreaSidebarOpen && store.areaSidebarOpen) {
                closeAreaSidebar();
            }
        }
    }["StoreHydrator.useEffect"], [
        searchParams,
        selectArea,
        openAreaSidebar,
        closeAreaSidebar
    ]);
    // Seed tools param from URL on initial mount only (deep-link support).
    // After mount, tools param is owned by the store and synced to URL via
    // window.history.pushState — no Next.js re-render needed for tools.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StoreHydrator.useEffect": ()=>{
            const tools = searchParams.get("tools");
            const store = __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"].getState();
            if (store.toolsParam === null && tools) {
                setToolsParam(tools);
            } else if (store.toolsParam !== null && !tools) {
            // URL has no tools but store does — store wins, do nothing.
            }
        // Intentionally run only once on mount.
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["StoreHydrator.useEffect"], []);
    // Sync MUI color mode to store whenever it changes.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StoreHydrator.useEffect": ()=>{
            if (mode === "light" || mode === "dark" || mode === "system") {
                setColorMode(mode);
            }
        }
    }["StoreHydrator.useEffect"], [
        mode,
        setColorMode
    ]);
    return null;
}
_s(StoreHydrator, "s7KPel49m10m/eKWSZSA/YjM9zA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useColorScheme"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"]
    ];
});
_c = StoreHydrator;
var _c;
__turbopack_context__.k.register(_c, "StoreHydrator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/StatusDot.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StatusDot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
;
;
;
;
function StatusDot(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    if ($[0] !== "f2422126e6f5066a81f768c90c77907cd3af18523fbb56c4f5eb65f9ae6db207") {
        for(let $i = 0; $i < 13; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f2422126e6f5066a81f768c90c77907cd3af18523fbb56c4f5eb65f9ae6db207";
    }
    const { color: t1, label, size: t2 } = t0;
    const color = t1 === undefined ? "success" : t1;
    const size = t2 === undefined ? 8 : t2;
    const t3 = `${color}.main`;
    let t4;
    if ($[1] !== size || $[2] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                width: size,
                height: size,
                borderRadius: "50%",
                backgroundColor: t3,
                flexShrink: 0,
                filter: _temp
            }
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/StatusDot.tsx",
            lineNumber: 27,
            columnNumber: 10
        }, this);
        $[1] = size;
        $[2] = t3;
        $[3] = t4;
    } else {
        t4 = $[3];
    }
    const dot = t4;
    if (!label) {
        return dot;
    }
    let t5;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            display: "flex",
            alignItems: "center",
            gap: 0.75
        };
        $[4] = t5;
    } else {
        t5 = $[4];
    }
    const t6 = `${color}.main`;
    let t7;
    if ($[5] !== t6) {
        t7 = {
            color: t6,
            fontWeight: 600,
            lineHeight: 1
        };
        $[5] = t6;
        $[6] = t7;
    } else {
        t7 = $[6];
    }
    let t8;
    if ($[7] !== label || $[8] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            sx: t7,
            children: label
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/StatusDot.tsx",
            lineNumber: 71,
            columnNumber: 10
        }, this);
        $[7] = label;
        $[8] = t7;
        $[9] = t8;
    } else {
        t8 = $[9];
    }
    let t9;
    if ($[10] !== dot || $[11] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t5,
            children: [
                dot,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/StatusDot.tsx",
            lineNumber: 80,
            columnNumber: 10
        }, this);
        $[10] = dot;
        $[11] = t8;
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    return t9;
}
_c = StatusDot;
function _temp(t) {
    return t.palette.mode === "dark" ? "drop-shadow(0 0 4px currentColor)" : "none";
}
var _c;
__turbopack_context__.k.register(_c, "StatusDot");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/AreaListItem.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AreaListItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RoomRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/RoomRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemButton/ListItemButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$StatusDot$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/StatusDot.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
function AreaListItem(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(31);
    if ($[0] !== "142239b4118ef334a4bea505b9495b8bce12e0ffa5982e68cc73ce4fa5abbe2a") {
        for(let $i = 0; $i < 31; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "142239b4118ef334a4bea505b9495b8bce12e0ffa5982e68cc73ce4fa5abbe2a";
    }
    const { area, selected, href } = t0;
    const t1 = `cy-area-item-${area.slug}`;
    const t2 = selected ? "inset 3px 0 0 0 var(--mui-palette-sidebar-itemBorderActive)" : "none";
    let t3;
    let t4;
    let t5;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            backgroundColor: "sidebar.itemBgActive"
        };
        t4 = {
            backgroundColor: "sidebar.itemBgActiveHover"
        };
        t5 = {
            backgroundColor: "action.hover",
            borderRadius: 1
        };
        $[1] = t3;
        $[2] = t4;
        $[3] = t5;
    } else {
        t3 = $[1];
        t4 = $[2];
        t5 = $[3];
    }
    let t6;
    if ($[4] !== t2) {
        t6 = {
            px: 1,
            py: "10px",
            borderRadius: 0,
            borderBottom: "1px solid",
            borderColor: "divider",
            alignItems: "flex-start",
            gap: 1,
            backgroundColor: "transparent",
            boxShadow: t2,
            "&.Mui-selected": t3,
            "&.Mui-selected:hover": t4,
            "&:hover": t5
        };
        $[4] = t2;
        $[5] = t6;
    } else {
        t6 = $[5];
    }
    let t7;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RoomRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: 18,
                color: "sidebar.mutedText",
                mt: "2px",
                flexShrink: 0
            }
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AreaListItem.tsx",
            lineNumber: 76,
            columnNumber: 10
        }, this);
        $[6] = t7;
    } else {
        t7 = $[6];
    }
    let t8;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            minWidth: 0,
            flex: 1
        };
        $[7] = t8;
    } else {
        t8 = $[7];
    }
    let t9;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = {
            display: "flex",
            alignItems: "center",
            gap: 0.75,
            mb: 0.25
        };
        $[8] = t9;
    } else {
        t9 = $[8];
    }
    let t10;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = {
            fontSize: 11,
            color: "sidebar.mutedText",
            fontWeight: 600,
            letterSpacing: "0.06em",
            flexShrink: 0
        };
        $[9] = t10;
    } else {
        t10 = $[9];
    }
    let t11;
    if ($[10] !== area.code) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t10,
            children: area.code
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AreaListItem.tsx",
            lineNumber: 123,
            columnNumber: 11
        }, this);
        $[10] = area.code;
        $[11] = t11;
    } else {
        t11 = $[11];
    }
    let t12;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = {
            fontWeight: 600,
            color: "sidebar.text",
            flex: 1,
            minWidth: 0,
            fontSize: "0.85rem"
        };
        $[12] = t12;
    } else {
        t12 = $[12];
    }
    let t13;
    if ($[13] !== area.title) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "subtitle2",
            noWrap: true,
            sx: t12,
            children: area.title
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AreaListItem.tsx",
            lineNumber: 144,
            columnNumber: 11
        }, this);
        $[13] = area.title;
        $[14] = t13;
    } else {
        t13 = $[14];
    }
    let t14;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$StatusDot$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: 6
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AreaListItem.tsx",
            lineNumber: 152,
            columnNumber: 11
        }, this);
        $[15] = t14;
    } else {
        t14 = $[15];
    }
    let t15;
    if ($[16] !== t11 || $[17] !== t13) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t9,
            children: [
                t11,
                t13,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/AreaListItem.tsx",
            lineNumber: 159,
            columnNumber: 11
        }, this);
        $[16] = t11;
        $[17] = t13;
        $[18] = t15;
    } else {
        t15 = $[18];
    }
    let t16;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = {
            color: "sidebar.mutedText",
            fontSize: "0.78rem",
            lineHeight: 1.4,
            display: "-webkit-box",
            WebkitLineClamp: 2,
            WebkitBoxOrient: "vertical",
            overflow: "hidden"
        };
        $[19] = t16;
    } else {
        t16 = $[19];
    }
    let t17;
    if ($[20] !== area.description) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t16,
            children: area.description
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AreaListItem.tsx",
            lineNumber: 183,
            columnNumber: 11
        }, this);
        $[20] = area.description;
        $[21] = t17;
    } else {
        t17 = $[21];
    }
    let t18;
    if ($[22] !== t15 || $[23] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t8,
            children: [
                t15,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/AreaListItem.tsx",
            lineNumber: 191,
            columnNumber: 11
        }, this);
        $[22] = t15;
        $[23] = t17;
        $[24] = t18;
    } else {
        t18 = $[24];
    }
    let t19;
    if ($[25] !== href || $[26] !== selected || $[27] !== t1 || $[28] !== t18 || $[29] !== t6) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            component: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
            href: href,
            selected: selected,
            "data-testid": t1,
            sx: t6,
            children: [
                t7,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/AreaListItem.tsx",
            lineNumber: 200,
            columnNumber: 11
        }, this);
        $[25] = href;
        $[26] = selected;
        $[27] = t1;
        $[28] = t18;
        $[29] = t6;
        $[30] = t19;
    } else {
        t19 = $[30];
    }
    return t19;
}
_c = AreaListItem;
var _c;
__turbopack_context__.k.register(_c, "AreaListItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/GhostInput.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GhostInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript)");
;
;
;
function GhostInput(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "5ff715ed16f046ce496f7dac65cfad3b7b80eb7ff9fb1db1c69248af46d0145a") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5ff715ed16f046ce496f7dac65cfad3b7b80eb7ff9fb1db1c69248af46d0145a";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = {
            "& .MuiOutlinedInput-root": {
                backgroundColor: _temp,
                borderRadius: 2,
                "& fieldset": {
                    border: _temp2
                },
                "&:hover fieldset": {
                    borderColor: _temp3
                },
                "&.Mui-focused fieldset": {
                    border: "1.5px solid",
                    borderColor: "primary.main"
                }
            }
        };
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] !== props.sx) {
        t1 = Array.isArray(props.sx) ? props.sx : props.sx ? [
            props.sx
        ] : [];
        $[2] = props.sx;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    let t2;
    if ($[4] !== t1) {
        t2 = [
            t0,
            ...t1
        ];
        $[4] = t1;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    let t3;
    if ($[6] !== props || $[7] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: "small",
            ...props,
            sx: t2
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/GhostInput.tsx",
            lineNumber: 52,
            columnNumber: 10
        }, this);
        $[6] = props;
        $[7] = t2;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    return t3;
}
_c = GhostInput;
function _temp3(t_1) {
    return t_1.palette.mode === "dark" ? "rgba(196,167,106,0.28)" : "none";
}
function _temp2(t_0) {
    return t_0.palette.mode === "dark" ? "1px solid rgba(196,167,106,0.16)" : "none";
}
function _temp(t) {
    return t.palette.mode === "dark" ? "rgba(255,255,255,0.045)" : "#E9E4D8";
}
var _c;
__turbopack_context__.k.register(_c, "GhostInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/PanelHeader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PanelHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Divider/Divider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
;
;
;
;
;
function PanelHeader(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(12);
    if ($[0] !== "122b400dd7b42dad3fb509e93be11ace6ac573af602a7a93884d765be70417f9") {
        for(let $i = 0; $i < 12; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "122b400dd7b42dad3fb509e93be11ace6ac573af602a7a93884d765be70417f9";
    }
    const { title, children } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            mb: 1.5
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            mb: 1
        };
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            fontSize: 11,
            fontWeight: 700,
            letterSpacing: "0.12em",
            textTransform: "uppercase",
            color: "sidebar.mutedText"
        };
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    let t4;
    if ($[4] !== title) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t3,
            children: title
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/PanelHeader.tsx",
            lineNumber: 58,
            columnNumber: 10
        }, this);
        $[4] = title;
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] !== children || $[7] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t2,
            children: [
                t4,
                children
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/PanelHeader.tsx",
            lineNumber: 66,
            columnNumber: 10
        }, this);
        $[6] = children;
        $[7] = t4;
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Divider$2f$Divider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/packages/app/src/components/PanelHeader.tsx",
            lineNumber: 75,
            columnNumber: 10
        }, this);
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    let t7;
    if ($[10] !== t5) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t1,
            children: [
                t5,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/PanelHeader.tsx",
            lineNumber: 82,
            columnNumber: 10
        }, this);
        $[10] = t5;
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    return t7;
}
_c = PanelHeader;
var _c;
__turbopack_context__.k.register(_c, "PanelHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/CollapseButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CollapseButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronLeftRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ChevronLeftRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronRightRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ChevronRightRounded.js [app-client] (ecmascript)");
;
;
;
;
;
function CollapseButton(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    if ($[0] !== "b414f5f5b93cae18d4c417ca159ca503ae0046489c0be154af8c82677d043ef0") {
        for(let $i = 0; $i < 13; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b414f5f5b93cae18d4c417ca159ca503ae0046489c0be154af8c82677d043ef0";
    }
    const { direction, onClick, testId, sx } = t0;
    const Icon = direction === "left" ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronLeftRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronRightRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            color: "sidebar.mutedText",
            "&:hover": {
                color: "text.primary"
            }
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== sx) {
        t2 = Array.isArray(sx) ? sx : [
            sx
        ];
        $[2] = sx;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] !== t2) {
        t3 = [
            t1,
            ...t2
        ];
        $[4] = t2;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    if ($[6] !== Icon) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {}, void 0, false, {
            fileName: "[project]/packages/app/src/components/CollapseButton.tsx",
            lineNumber: 57,
            columnNumber: 10
        }, this);
        $[6] = Icon;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    if ($[8] !== onClick || $[9] !== t3 || $[10] !== t4 || $[11] !== testId) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: "small",
            onClick: onClick,
            "aria-label": "Collapse sidebar",
            "data-testid": testId,
            sx: t3,
            children: t4
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/CollapseButton.tsx",
            lineNumber: 65,
            columnNumber: 10
        }, this);
        $[8] = onClick;
        $[9] = t3;
        $[10] = t4;
        $[11] = testId;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    return t5;
}
_c = CollapseButton;
var _c;
__turbopack_context__.k.register(_c, "CollapseButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/AreaSidebar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AreaSidebar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$AreaListItem$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/AreaListItem.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$GhostInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/GhostInput.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$PanelHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/PanelHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$CollapseButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/CollapseButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/useGameStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$urlSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/urlSync.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
function AreaSidebar(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(21);
    if ($[0] !== "09d4fd4de35a53156968693ceb895a0b83012294be90bdff2fe28d64449dfede") {
        for(let $i = 0; $i < 21; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "09d4fd4de35a53156968693ceb895a0b83012294be90bdff2fe28d64449dfede";
    }
    const { areas, selectedSlug } = t0;
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const closeAreaSidebar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_AreaSidebarUseGameStore);
    const toolsParam = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_AreaSidebarUseGameStore2);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    let t1;
    if ($[1] !== closeAreaSidebar || $[2] !== router || $[3] !== selectedSlug || $[4] !== toolsParam) {
        t1 = ({
            "AreaSidebar[handleCollapse]": ()=>{
                closeAreaSidebar();
                router.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$urlSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildUrlFromState"])({
                    areaSidebarOpen: false,
                    selectedAreaSlug: selectedSlug ?? null,
                    toolsParam
                }));
            }
        })["AreaSidebar[handleCollapse]"];
        $[1] = closeAreaSidebar;
        $[2] = router;
        $[3] = selectedSlug;
        $[4] = toolsParam;
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    const handleCollapse = t1;
    let t2;
    if ($[6] !== areas || $[7] !== handleCollapse || $[8] !== search || $[9] !== selectedSlug) {
        let t3;
        if ($[11] !== search) {
            t3 = ({
                "AreaSidebar[areas.filter()]": (area)=>{
                    const q = search.toLowerCase();
                    return area.code.toLowerCase().includes(q) || area.title.toLowerCase().includes(q);
                }
            })["AreaSidebar[areas.filter()]"];
            $[11] = search;
            $[12] = t3;
        } else {
            t3 = $[12];
        }
        const filtered = areas.filter(t3);
        let t4;
        if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = {
                display: "flex",
                flexDirection: "column",
                flex: 1,
                minHeight: 0,
                p: 2
            };
            $[13] = t4;
        } else {
            t4 = $[13];
        }
        let t5;
        if ($[14] !== handleCollapse) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$PanelHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: "Areas",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$CollapseButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    direction: "left",
                    onClick: handleCollapse,
                    testId: "cy-area-collapse-button"
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/AreaSidebar.tsx",
                    lineNumber: 88,
                    columnNumber: 39
                }, this)
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/AreaSidebar.tsx",
                lineNumber: 88,
                columnNumber: 12
            }, this);
            $[14] = handleCollapse;
            $[15] = t5;
        } else {
            t5 = $[15];
        }
        let t6;
        let t7;
        let t8;
        if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = ({
                "AreaSidebar[<GhostInput>.onChange]": (e)=>setSearch(e.target.value)
            })["AreaSidebar[<GhostInput>.onChange]"];
            t7 = {
                htmlInput: {
                    "data-testid": "cy-area-search-input"
                }
            };
            t8 = {
                mb: 1.5
            };
            $[16] = t6;
            $[17] = t7;
            $[18] = t8;
        } else {
            t6 = $[16];
            t7 = $[17];
            t8 = $[18];
        }
        let t9;
        if ($[19] !== search) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$GhostInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                placeholder: "Search by code or title",
                fullWidth: true,
                value: search,
                onChange: t6,
                slotProps: t7,
                sx: t8
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/AreaSidebar.tsx",
                lineNumber: 119,
                columnNumber: 12
            }, this);
            $[19] = search;
            $[20] = t9;
        } else {
            t9 = $[20];
        }
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t4,
            children: [
                t5,
                t9,
                areas.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    color: "text.secondary",
                    variant: "body2",
                    sx: {
                        mt: 2
                    },
                    children: "No area files were found in src/content/areas."
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/AreaSidebar.tsx",
                    lineNumber: 125,
                    columnNumber: 53
                }, this) : filtered.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    color: "text.secondary",
                    variant: "body2",
                    sx: {
                        mt: 2
                    },
                    children: "No areas match your search."
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/AreaSidebar.tsx",
                    lineNumber: 127,
                    columnNumber: 96
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    disablePadding: true,
                    sx: {
                        flex: 1,
                        overflowY: "auto"
                    },
                    children: filtered.map({
                        "AreaSidebar[filtered.map()]": (area_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$AreaListItem$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                area: area_0,
                                selected: selectedSlug === area_0.slug,
                                href: `/?sidebar=areas&area=${area_0.slug}`
                            }, area_0.slug, false, {
                                fileName: "[project]/packages/app/src/components/AreaSidebar.tsx",
                                lineNumber: 133,
                                columnNumber: 52
                            }, this)
                    }["AreaSidebar[filtered.map()]"])
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/AreaSidebar.tsx",
                    lineNumber: 129,
                    columnNumber: 53
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/AreaSidebar.tsx",
            lineNumber: 125,
            columnNumber: 10
        }, this);
        $[6] = areas;
        $[7] = handleCollapse;
        $[8] = search;
        $[9] = selectedSlug;
        $[10] = t2;
    } else {
        t2 = $[10];
    }
    return t2;
}
_s(AreaSidebar, "Eacz5H6gn7OXaEsi1tVJFVlzaEQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = AreaSidebar;
function _AreaSidebarUseGameStore2(s_0) {
    return s_0.toolsParam;
}
function _AreaSidebarUseGameStore(s) {
    return s.closeAreaSidebar;
}
var _c;
__turbopack_context__.k.register(_c, "AreaSidebar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/LeftRail.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LeftRail
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ConstructionRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ConstructionRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$DarkModeRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/DarkModeRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$HomeRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/HomeRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$LightModeRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/LightModeRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MenuBookRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/MenuBookRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Tooltip/Tooltip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/ThemeProviderWithVars.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/useGameStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$urlSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/urlSync.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
const navItems = [
    {
        id: "dashboard",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$HomeRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        label: "Dashboard",
        testId: "cy-rail-dashboard"
    },
    {
        id: "areas",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$MenuBookRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        label: "Area Compendium",
        testId: "cy-rail-areas"
    },
    {
        id: "tools",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ConstructionRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        label: "Session Tools",
        testId: "cy-rail-tools"
    }
];
function LeftRail() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(52);
    if ($[0] !== "703b248bd589195713d7c7fca8967f935cda076262923718ca07559bf550f561") {
        for(let $i = 0; $i < 52; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "703b248bd589195713d7c7fca8967f935cda076262923718ca07559bf550f561";
    }
    const { mode, setMode, colorScheme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useColorScheme"])();
    const areaSidebarOpen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_LeftRailUseGameStore);
    const selectedAreaSlug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_LeftRailUseGameStore2);
    const toolsParam = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_LeftRailUseGameStore3);
    const openAreaSidebar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_LeftRailUseGameStore4);
    const closeAreaSidebar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_LeftRailUseGameStore5);
    const closeTools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_LeftRailUseGameStore6);
    const setToolsParam = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_LeftRailUseGameStore7);
    const closeStatBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_LeftRailUseGameStore8);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    let t0;
    if ($[1] !== closeAreaSidebar || $[2] !== closeStatBlock || $[3] !== closeTools || $[4] !== router) {
        t0 = ({
            "LeftRail[navigateHome]": ()=>{
                closeAreaSidebar();
                closeTools();
                closeStatBlock();
                router.push("/");
            }
        })["LeftRail[navigateHome]"];
        $[1] = closeAreaSidebar;
        $[2] = closeStatBlock;
        $[3] = closeTools;
        $[4] = router;
        $[5] = t0;
    } else {
        t0 = $[5];
    }
    const navigateHome = t0;
    let t1;
    if ($[6] !== areaSidebarOpen || $[7] !== closeAreaSidebar || $[8] !== openAreaSidebar || $[9] !== router || $[10] !== selectedAreaSlug || $[11] !== toolsParam) {
        t1 = ({
            "LeftRail[handleToggleAreaSidebar]": ()=>{
                if (areaSidebarOpen) {
                    closeAreaSidebar();
                    router.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$urlSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildUrlFromState"])({
                        areaSidebarOpen: false,
                        selectedAreaSlug,
                        toolsParam
                    }));
                } else {
                    openAreaSidebar();
                }
            }
        })["LeftRail[handleToggleAreaSidebar]"];
        $[6] = areaSidebarOpen;
        $[7] = closeAreaSidebar;
        $[8] = openAreaSidebar;
        $[9] = router;
        $[10] = selectedAreaSlug;
        $[11] = toolsParam;
        $[12] = t1;
    } else {
        t1 = $[12];
    }
    const handleToggleAreaSidebar = t1;
    let t2;
    if ($[13] !== closeTools || $[14] !== setToolsParam || $[15] !== toolsParam) {
        t2 = ({
            "LeftRail[toggleToolsSidebar]": ()=>{
                if (toolsParam !== null) {
                    closeTools();
                } else {
                    setToolsParam("menu");
                }
            }
        })["LeftRail[toggleToolsSidebar]"];
        $[13] = closeTools;
        $[14] = setToolsParam;
        $[15] = toolsParam;
        $[16] = t2;
    } else {
        t2 = $[16];
    }
    const toggleToolsSidebar = t2;
    const isDark = colorScheme === "dark" || mode === "dark";
    let t3;
    if ($[17] !== isDark || $[18] !== setMode) {
        t3 = ({
            "LeftRail[toggleColorMode]": ()=>{
                setMode(isDark ? "light" : "dark");
            }
        })["LeftRail[toggleColorMode]"];
        $[17] = isDark;
        $[18] = setMode;
        $[19] = t3;
    } else {
        t3 = $[19];
    }
    const toggleColorMode = t3;
    let t4;
    if ($[20] !== areaSidebarOpen || $[21] !== toolsParam) {
        t4 = ({
            "LeftRail[isActive]": (id)=>{
                if (id === "areas") {
                    return areaSidebarOpen;
                }
                if (id === "tools") {
                    return toolsParam !== null;
                }
                return false;
            }
        })["LeftRail[isActive]"];
        $[20] = areaSidebarOpen;
        $[21] = toolsParam;
        $[22] = t4;
    } else {
        t4 = $[22];
    }
    const isActive = t4;
    let t5;
    if ($[23] !== handleToggleAreaSidebar || $[24] !== navigateHome || $[25] !== toggleToolsSidebar) {
        t5 = ({
            "LeftRail[handleNav]": (id_0)=>{
                if (id_0 === "dashboard") {
                    navigateHome();
                } else {
                    if (id_0 === "areas") {
                        handleToggleAreaSidebar();
                    } else {
                        if (id_0 === "tools") {
                            toggleToolsSidebar();
                        }
                    }
                }
            }
        })["LeftRail[handleNav]"];
        $[23] = handleToggleAreaSidebar;
        $[24] = navigateHome;
        $[25] = toggleToolsSidebar;
        $[26] = t5;
    } else {
        t5 = $[26];
    }
    const handleNav = t5;
    let t6;
    if ($[27] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            xs: 72,
            lg: 4
        };
        $[27] = t6;
    } else {
        t6 = $[27];
    }
    let t7;
    if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            width: t6,
            overflow: "hidden",
            transition: "width 0.2s ease",
            "&:hover": {
                width: 72
            },
            height: "100vh",
            position: "sticky",
            top: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            flexShrink: 0,
            borderRight: "1px solid",
            borderColor: "chrome.railBorder",
            backgroundColor: "chrome.railBg",
            zIndex: 100
        };
        $[28] = t7;
    } else {
        t7 = $[28];
    }
    let t8;
    if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            mt: 2,
            mb: 3,
            width: 42,
            height: 42,
            borderRadius: 1.5,
            border: "1px solid",
            borderColor: "chrome.railBorder",
            display: "grid",
            placeItems: "center",
            fontFamily: "var(--font-display), serif",
            fontSize: "0.85rem",
            letterSpacing: "0.12em",
            color: "primary.main",
            cursor: "pointer",
            userSelect: "none"
        };
        $[29] = t8;
    } else {
        t8 = $[29];
    }
    let t9;
    if ($[30] !== navigateHome) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t8,
            onClick: navigateHome,
            "data-testid": "cy-rail-logo",
            children: "GM"
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/LeftRail.tsx",
            lineNumber: 240,
            columnNumber: 10
        }, this);
        $[30] = navigateHome;
        $[31] = t9;
    } else {
        t9 = $[31];
    }
    let t10;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = {
            flex: 1,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 0.5
        };
        $[32] = t10;
    } else {
        t10 = $[32];
    }
    let t11;
    if ($[33] !== handleNav || $[34] !== isActive) {
        t11 = navItems.map({
            "LeftRail[navItems.map()]": (t12)=>{
                const { id: id_1, icon: Icon, label, testId } = t12;
                const active = isActive(id_1);
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        position: "relative",
                        width: 48,
                        display: "flex",
                        justifyContent: "center"
                    },
                    children: [
                        active && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            sx: {
                                position: "absolute",
                                right: 0,
                                top: "50%",
                                transform: "translateY(-50%)",
                                width: 3,
                                height: 28,
                                borderRadius: "2px 0 0 2px",
                                backgroundColor: "chrome.railActiveMark",
                                boxShadow: "chrome.railActiveGlow"
                            }
                        }, void 0, false, {
                            fileName: "[project]/packages/app/src/components/LeftRail.tsx",
                            lineNumber: 275,
                            columnNumber: 23
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            title: label,
                            placement: "right",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                onClick: {
                                    "LeftRail[navItems.map() > <IconButton>.onClick]": ()=>handleNav(id_1)
                                }["LeftRail[navItems.map() > <IconButton>.onClick]"],
                                "data-testid": testId,
                                "aria-label": label,
                                sx: {
                                    color: active ? "chrome.railActiveIcon" : "chrome.mutedText",
                                    transition: "transform 0.15s ease, color 0.15s ease",
                                    "&:hover": {
                                        transform: "translateY(-1px)",
                                        backgroundColor: "transparent"
                                    },
                                    ...active && {
                                        filter: _temp
                                    }
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {}, void 0, false, {
                                    fileName: "[project]/packages/app/src/components/LeftRail.tsx",
                                    lineNumber: 297,
                                    columnNumber: 16
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/packages/app/src/components/LeftRail.tsx",
                                lineNumber: 285,
                                columnNumber: 58
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/app/src/components/LeftRail.tsx",
                            lineNumber: 285,
                            columnNumber: 17
                        }, this)
                    ]
                }, id_1, true, {
                    fileName: "[project]/packages/app/src/components/LeftRail.tsx",
                    lineNumber: 270,
                    columnNumber: 16
                }, this);
            }
        }["LeftRail[navItems.map()]"]);
        $[33] = handleNav;
        $[34] = isActive;
        $[35] = t11;
    } else {
        t11 = $[35];
    }
    let t12;
    if ($[36] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t10,
            children: t11
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/LeftRail.tsx",
            lineNumber: 308,
            columnNumber: 11
        }, this);
        $[36] = t11;
        $[37] = t12;
    } else {
        t12 = $[37];
    }
    const t13 = colorScheme === "dark" ? "Light mode" : "Dark mode";
    const t14 = colorScheme === "dark" ? "Switch to light mode" : "Switch to dark mode";
    let t15;
    if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = {
            mb: 2,
            color: "chrome.mutedText",
            transition: "transform 0.15s ease",
            "&:hover": {
                transform: "translateY(-1px)",
                backgroundColor: "transparent"
            }
        };
        $[38] = t15;
    } else {
        t15 = $[38];
    }
    let t16;
    if ($[39] !== colorScheme) {
        t16 = colorScheme === "dark" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$LightModeRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/packages/app/src/components/LeftRail.tsx",
            lineNumber: 333,
            columnNumber: 36
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$DarkModeRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/packages/app/src/components/LeftRail.tsx",
            lineNumber: 333,
            columnNumber: 63
        }, this);
        $[39] = colorScheme;
        $[40] = t16;
    } else {
        t16 = $[40];
    }
    let t17;
    if ($[41] !== t14 || $[42] !== t16 || $[43] !== toggleColorMode) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: toggleColorMode,
            "aria-label": t14,
            "data-testid": "cy-rail-theme-toggle",
            sx: t15,
            children: t16
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/LeftRail.tsx",
            lineNumber: 341,
            columnNumber: 11
        }, this);
        $[41] = t14;
        $[42] = t16;
        $[43] = toggleColorMode;
        $[44] = t17;
    } else {
        t17 = $[44];
    }
    let t18;
    if ($[45] !== t13 || $[46] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Tooltip$2f$Tooltip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: t13,
            placement: "right",
            children: t17
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/LeftRail.tsx",
            lineNumber: 351,
            columnNumber: 11
        }, this);
        $[45] = t13;
        $[46] = t17;
        $[47] = t18;
    } else {
        t18 = $[47];
    }
    let t19;
    if ($[48] !== t12 || $[49] !== t18 || $[50] !== t9) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            component: "nav",
            sx: t7,
            children: [
                t9,
                t12,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/LeftRail.tsx",
            lineNumber: 360,
            columnNumber: 11
        }, this);
        $[48] = t12;
        $[49] = t18;
        $[50] = t9;
        $[51] = t19;
    } else {
        t19 = $[51];
    }
    return t19;
}
_s(LeftRail, "A/vR285GHdH6mAVWbyB6oeYDXV4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProviderWithVars$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useColorScheme"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = LeftRail;
function _temp(t) {
    return t.palette.mode === "dark" ? "drop-shadow(0 0 6px currentColor)" : "none";
}
function _LeftRailUseGameStore8(s_6) {
    return s_6.closeStatBlock;
}
function _LeftRailUseGameStore7(s_5) {
    return s_5.setToolsParam;
}
function _LeftRailUseGameStore6(s_4) {
    return s_4.closeTools;
}
function _LeftRailUseGameStore5(s_3) {
    return s_3.closeAreaSidebar;
}
function _LeftRailUseGameStore4(s_2) {
    return s_2.openAreaSidebar;
}
function _LeftRailUseGameStore3(s_1) {
    return s_1.toolsParam;
}
function _LeftRailUseGameStore2(s_0) {
    return s_0.selectedAreaSlug;
}
function _LeftRailUseGameStore(s) {
    return s.areaSidebarOpen;
}
var _c;
__turbopack_context__.k.register(_c, "LeftRail");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/PanelColumn.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PanelColumn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
;
;
;
function PanelColumn(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    if ($[0] !== "fb72acc6164a2924c9e2c28e2d52f34d9d029abdae55ecf54872afdab3db2c01") {
        for(let $i = 0; $i < 13; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "fb72acc6164a2924c9e2c28e2d52f34d9d029abdae55ecf54872afdab3db2c01";
    }
    const { width, side, children, sx } = t0;
    const t1 = side === "right" ? "1px solid" : "none";
    const t2 = side === "left" ? "1px solid" : "none";
    let t3;
    if ($[1] !== t1 || $[2] !== t2 || $[3] !== width) {
        t3 = {
            width,
            flexShrink: 0,
            flexDirection: "column",
            height: "100vh",
            position: "sticky",
            top: 0,
            overflowY: "auto",
            backgroundColor: "background.paper",
            borderLeft: t1,
            borderRight: t2,
            borderColor: "chrome.railBorder"
        };
        $[1] = t1;
        $[2] = t2;
        $[3] = width;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] !== sx) {
        t4 = Array.isArray(sx) ? sx : [
            sx
        ];
        $[5] = sx;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    let t5;
    if ($[7] !== t3 || $[8] !== t4) {
        t5 = [
            t3,
            ...t4
        ];
        $[7] = t3;
        $[8] = t4;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    if ($[10] !== children || $[11] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            component: "aside",
            sx: t5,
            children: children
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/PanelColumn.tsx",
            lineNumber: 68,
            columnNumber: 10
        }, this);
        $[10] = children;
        $[11] = t5;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    return t6;
}
_c = PanelColumn;
var _c;
__turbopack_context__.k.register(_c, "PanelColumn");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/MonsterHpChip.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MonsterHpChip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/lib/initiative.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function MonsterHpChip(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "3d5d730a1e212583da6246ad36907e288beec59a08b72bbe315a1fe85a9cea04") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "3d5d730a1e212583da6246ad36907e288beec59a08b72bbe315a1fe85a9cea04";
    }
    const { id, name, currentHp, maxHp, onSetHp } = t0;
    const [isEditing, setIsEditing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [draftHp, setDraftHp] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(String(currentHp));
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const skipBlurCommitRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    let t1;
    let t2;
    if ($[1] !== isEditing) {
        t1 = ({
            "MonsterHpChip[useEffect()]": ()=>{
                if (isEditing) {
                    inputRef.current?.focus();
                    inputRef.current?.select();
                }
            }
        })["MonsterHpChip[useEffect()]"];
        t2 = [
            isEditing
        ];
        $[1] = isEditing;
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "MonsterHpChip[exitEditor]": ()=>{
                setIsEditing(false);
                skipBlurCommitRef.current = false;
            }
        })["MonsterHpChip[exitEditor]"];
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    const exitEditor = t3;
    let t4;
    if ($[5] !== draftHp || $[6] !== id || $[7] !== onSetHp) {
        t4 = ({
            "MonsterHpChip[commitDraft]": ()=>{
                onSetHp(id, draftHp);
                exitEditor();
            }
        })["MonsterHpChip[commitDraft]"];
        $[5] = draftHp;
        $[6] = id;
        $[7] = onSetHp;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    const commitDraft = t4;
    let t5;
    if ($[9] !== commitDraft || $[10] !== currentHp || $[11] !== draftHp || $[12] !== isEditing || $[13] !== maxHp || $[14] !== name) {
        t5 = isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            inputRef: inputRef,
            size: "small",
            type: "number",
            value: draftHp,
            onChange: {
                "MonsterHpChip[<TextField>.onChange]": (event)=>setDraftHp(event.target.value)
            }["MonsterHpChip[<TextField>.onChange]"],
            onBlur: {
                "MonsterHpChip[<TextField>.onBlur]": ()=>{
                    if (skipBlurCommitRef.current) {
                        skipBlurCommitRef.current = false;
                        return;
                    }
                    commitDraft();
                }
            }["MonsterHpChip[<TextField>.onBlur]"],
            onKeyDown: {
                "MonsterHpChip[<TextField>.onKeyDown]": (event_0)=>{
                    if (event_0.key === "Enter") {
                        event_0.preventDefault();
                        commitDraft();
                    }
                    if (event_0.key === "Escape") {
                        event_0.preventDefault();
                        skipBlurCommitRef.current = true;
                        setDraftHp(String(currentHp));
                        exitEditor();
                    }
                }
            }["MonsterHpChip[<TextField>.onKeyDown]"],
            sx: {
                width: 74,
                "& .MuiInputBase-root": {
                    height: 32,
                    color: "inherit"
                },
                "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "currentColor"
                }
            },
            slotProps: {
                htmlInput: {
                    min: 0,
                    max: maxHp,
                    inputMode: "numeric",
                    "aria-label": `Current HP for ${name}`,
                    "data-testid": `cy-initiative-hp-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTestId"])(name)}`
                }
            }
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterHpChip.tsx",
            lineNumber: 85,
            columnNumber: 22
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            clickable: true,
            size: "small",
            variant: "outlined",
            label: `HP ${currentHp}/${maxHp}`,
            onClick: {
                "MonsterHpChip[<Chip>.onClick]": (event_1)=>{
                    event_1.stopPropagation();
                    setDraftHp(String(currentHp));
                    setIsEditing(true);
                }
            }["MonsterHpChip[<Chip>.onClick]"],
            "aria-label": `Edit HP for ${name}`,
            "data-testid": `cy-initiative-hp-chip-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTestId"])(name)}`,
            color: currentHp <= 0 ? "error" : currentHp < maxHp ? "warning" : "default",
            sx: {
                fontWeight: 700,
                maxWidth: 108,
                "& .MuiChip-label": {
                    px: 1
                }
            }
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterHpChip.tsx",
            lineNumber: 125,
            columnNumber: 13
        }, this);
        $[9] = commitDraft;
        $[10] = currentHp;
        $[11] = draftHp;
        $[12] = isEditing;
        $[13] = maxHp;
        $[14] = name;
        $[15] = t5;
    } else {
        t5 = $[15];
    }
    return t5;
}
_s(MonsterHpChip, "toc9/4BTSrIQr5dDFROA17pZNM4=");
_c = MonsterHpChip;
var _c;
__turbopack_context__.k.register(_c, "MonsterHpChip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/SkullIcon.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SkullIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$SvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/SvgIcon/SvgIcon.js [app-client] (ecmascript)");
;
;
;
function SkullIcon(props) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "740383c6f7cb8c64d1eaae60f7fdc4c5e5d11ec5d6e2de58b5efd8452cc86d41") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "740383c6f7cb8c64d1eaae60f7fdc4c5e5d11ec5d6e2de58b5efd8452cc86d41";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M12 2C7.58 2 4 5.58 4 10c0 2.76 1.34 5.2 3.4 6.72V20c0 .55.45 1 1 1h1.1c.55 0 1-.45 1-1v-1h1v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h1v1c0 .55.45 1 1 1h1.1c.55 0 1-.45 1-1v-3.28C18.66 15.2 20 12.76 20 10c0-4.42-3.58-8-8-8zm-2.5 12a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm5 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z"
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/SkullIcon.tsx",
            lineNumber: 13,
            columnNumber: 10
        }, this);
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    let t1;
    if ($[2] !== props) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$SvgIcon$2f$SvgIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            ...props,
            viewBox: "0 0 24 24",
            children: t0
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/SkullIcon.tsx",
            lineNumber: 20,
            columnNumber: 10
        }, this);
        $[2] = props;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    return t1;
}
_c = SkullIcon;
var _c;
__turbopack_context__.k.register(_c, "SkullIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/SortableRow.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SortableRow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dnd-kit/sortable/dist/sortable.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dnd-kit/utilities/dist/utilities.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloseRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CloseRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$DragIndicatorRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/DragIndicatorRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RemoveRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/RemoveRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/lib/initiative.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$MonsterHpChip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/MonsterHpChip.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$SkullIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/SkullIcon.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function SortableRow(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(100);
    if ($[0] !== "d53cdeeeb6c63db323c409be9505b98f05de87cc0fd6ead7fe2dc20de97a1ef6") {
        for(let $i = 0; $i < 100; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d53cdeeeb6c63db323c409be9505b98f05de87cc0fd6ead7fe2dc20de97a1ef6";
    }
    const { char, isActive, onDelete, onToggleDying, onSetHp, onUpdateSaves } = t0;
    let t1;
    if ($[1] !== char.id) {
        t1 = {
            id: char.id
        };
        $[1] = char.id;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const { attributes, listeners, setNodeRef, transform, transition, isDragging } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSortable"])(t1);
    let t2;
    if ($[3] !== transform) {
        t2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CSS"].Transform.toString(transform);
        $[3] = transform;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const t3 = isDragging ? 0.5 : 1;
    let t4;
    if ($[5] !== t2 || $[6] !== t3 || $[7] !== transition) {
        t4 = {
            transform: t2,
            transition,
            opacity: t3
        };
        $[5] = t2;
        $[6] = t3;
        $[7] = transition;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    const style = t4;
    const isMonster = typeof char.maxHp === "number";
    const currentHp = isMonster ? char.hp ?? char.maxHp ?? 0 : null;
    const isSkipped = isMonster ? (currentHp ?? 0) <= 0 : char.dying && char.failures >= 3;
    const isStabilized = !isMonster && char.dying && char.successes >= 3;
    let t5;
    if ($[9] !== char.copyIndex || $[10] !== char.name) {
        t5 = char.copyIndex != null ? char.name.replace(/ \d+$/, "") : char.name;
        $[9] = char.copyIndex;
        $[10] = char.name;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    const baseDisplayName = t5;
    let t6;
    if ($[12] !== char.name) {
        t6 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTestId"])(char.name);
        $[12] = char.name;
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    const t7 = `cy-initiative-row-${t6}`;
    const t8 = isActive ? "true" : "false";
    const t9 = isSkipped ? "dead" : isStabilized ? "stabilized" : char.dying ? "dying" : "ready";
    let t10;
    if ($[14] !== char.dying || $[15] !== isActive || $[16] !== isSkipped) {
        t10 = isActive && !isSkipped && !char.dying && {
            bgcolor: "primary.main",
            color: "primary.contrastText"
        };
        $[14] = char.dying;
        $[15] = isActive;
        $[16] = isSkipped;
        $[17] = t10;
    } else {
        t10 = $[17];
    }
    let t11;
    if ($[18] !== char.dying || $[19] !== isActive || $[20] !== isMonster) {
        t11 = isActive && !isMonster && char.dying && {
            border: 2,
            borderColor: "primary.main"
        };
        $[18] = char.dying;
        $[19] = isActive;
        $[20] = isMonster;
        $[21] = t11;
    } else {
        t11 = $[21];
    }
    let t12;
    if ($[22] !== char.dying || $[23] !== isSkipped) {
        t12 = (char.dying || isSkipped) && {
            opacity: isSkipped ? 0.3 : 0.55,
            ...isSkipped && {
                textDecoration: "line-through"
            }
        };
        $[22] = char.dying;
        $[23] = isSkipped;
        $[24] = t12;
    } else {
        t12 = $[24];
    }
    let t13;
    if ($[25] !== t10 || $[26] !== t11 || $[27] !== t12) {
        t13 = {
            py: 0.75,
            px: 1,
            borderRadius: 2,
            flexWrap: "wrap",
            ...t10,
            ...t11,
            ...t12
        };
        $[25] = t10;
        $[26] = t11;
        $[27] = t12;
        $[28] = t13;
    } else {
        t13 = $[28];
    }
    let t14;
    let t15;
    if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = {
            display: "flex",
            cursor: "grab",
            color: "inherit"
        };
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$DragIndicatorRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/SortableRow.tsx",
            lineNumber: 176,
            columnNumber: 11
        }, this);
        $[29] = t14;
        $[30] = t15;
    } else {
        t14 = $[29];
        t15 = $[30];
    }
    let t16;
    if ($[31] !== attributes || $[32] !== listeners) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            ...attributes,
            ...listeners,
            sx: t14,
            children: t15
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/SortableRow.tsx",
            lineNumber: 185,
            columnNumber: 11
        }, this);
        $[31] = attributes;
        $[32] = listeners;
        $[33] = t16;
    } else {
        t16 = $[33];
    }
    let t17;
    if ($[34] !== char.name) {
        t17 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTestId"])(char.name);
        $[34] = char.name;
        $[35] = t17;
    } else {
        t17 = $[35];
    }
    const t18 = `cy-initiative-row-name-${t17}`;
    const t19 = isActive && !char.dying ? 700 : 400;
    let t20;
    if ($[36] !== t19) {
        t20 = {
            flex: 1,
            fontWeight: t19,
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
            minWidth: 0
        };
        $[36] = t19;
        $[37] = t20;
    } else {
        t20 = $[37];
    }
    let t21;
    if ($[38] !== baseDisplayName || $[39] !== t18 || $[40] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            "data-testid": t18,
            title: baseDisplayName,
            sx: t20,
            children: baseDisplayName
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/SortableRow.tsx",
            lineNumber: 219,
            columnNumber: 11
        }, this);
        $[38] = baseDisplayName;
        $[39] = t18;
        $[40] = t20;
        $[41] = t21;
    } else {
        t21 = $[41];
    }
    let t22;
    if ($[42] !== char.copyIndex) {
        t22 = char.copyIndex != null ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: `#${char.copyIndex}`,
            size: "small",
            variant: "outlined",
            sx: {
                fontWeight: 700
            }
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/SortableRow.tsx",
            lineNumber: 229,
            columnNumber: 36
        }, this) : null;
        $[42] = char.copyIndex;
        $[43] = t22;
    } else {
        t22 = $[43];
    }
    let t23;
    if ($[44] !== char.id || $[45] !== char.maxHp || $[46] !== char.name || $[47] !== currentHp || $[48] !== isMonster || $[49] !== onSetHp) {
        t23 = isMonster ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$MonsterHpChip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            id: char.id,
            name: char.name,
            currentHp: currentHp ?? 0,
            maxHp: char.maxHp ?? 0,
            onSetHp: onSetHp
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/SortableRow.tsx",
            lineNumber: 239,
            columnNumber: 23
        }, this) : null;
        $[44] = char.id;
        $[45] = char.maxHp;
        $[46] = char.name;
        $[47] = currentHp;
        $[48] = isMonster;
        $[49] = onSetHp;
        $[50] = t23;
    } else {
        t23 = $[50];
    }
    let t24;
    if ($[51] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = {
            fontWeight: 700,
            minWidth: 32,
            textAlign: "right"
        };
        $[51] = t24;
    } else {
        t24 = $[51];
    }
    let t25;
    if ($[52] !== char.total) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t24,
            children: char.total
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/SortableRow.tsx",
            lineNumber: 263,
            columnNumber: 11
        }, this);
        $[52] = char.total;
        $[53] = t25;
    } else {
        t25 = $[53];
    }
    let t26;
    if ($[54] !== char.dying || $[55] !== char.id || $[56] !== char.name || $[57] !== isMonster || $[58] !== onToggleDying) {
        t26 = !isMonster ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: "small",
            onClick: {
                "SortableRow[<IconButton>.onClick]": ()=>onToggleDying(char.id)
            }["SortableRow[<IconButton>.onClick]"],
            sx: {
                color: char.dying ? "error.main" : "inherit"
            },
            "aria-label": char.dying ? `Revive ${char.name}` : `Mark ${char.name} as dying`,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$SkullIcon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                fontSize: "small"
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/SortableRow.tsx",
                lineNumber: 275,
                columnNumber: 87
            }, this)
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/SortableRow.tsx",
            lineNumber: 271,
            columnNumber: 24
        }, this) : null;
        $[54] = char.dying;
        $[55] = char.id;
        $[56] = char.name;
        $[57] = isMonster;
        $[58] = onToggleDying;
        $[59] = t26;
    } else {
        t26 = $[59];
    }
    let t27;
    if ($[60] !== char.id || $[61] !== onDelete) {
        t27 = ({
            "SortableRow[<IconButton>.onClick]": ()=>onDelete(char.id)
        })["SortableRow[<IconButton>.onClick]"];
        $[60] = char.id;
        $[61] = onDelete;
        $[62] = t27;
    } else {
        t27 = $[62];
    }
    let t28;
    if ($[63] === Symbol.for("react.memo_cache_sentinel")) {
        t28 = {
            color: "inherit"
        };
        $[63] = t28;
    } else {
        t28 = $[63];
    }
    const t29 = `Remove ${char.name}`;
    let t30;
    if ($[64] === Symbol.for("react.memo_cache_sentinel")) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloseRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fontSize: "small"
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/SortableRow.tsx",
            lineNumber: 308,
            columnNumber: 11
        }, this);
        $[64] = t30;
    } else {
        t30 = $[64];
    }
    let t31;
    if ($[65] !== t27 || $[66] !== t29) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: "small",
            onClick: t27,
            sx: t28,
            "aria-label": t29,
            children: t30
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/SortableRow.tsx",
            lineNumber: 315,
            columnNumber: 11
        }, this);
        $[65] = t27;
        $[66] = t29;
        $[67] = t31;
    } else {
        t31 = $[67];
    }
    let t32;
    if ($[68] !== char.dying || $[69] !== char.failures || $[70] !== char.id || $[71] !== char.name || $[72] !== char.successes || $[73] !== isMonster || $[74] !== isSkipped || $[75] !== isStabilized || $[76] !== onUpdateSaves) {
        t32 = !isMonster && char.dying && !isStabilized && !isSkipped && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "row",
            alignItems: "center",
            spacing: 0.5,
            sx: {
                width: "100%",
                pl: 3.5,
                pt: 0.25
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    size: "small",
                    onClick: {
                        "SortableRow[<IconButton>.onClick]": ()=>onUpdateSaves(char.id, "successes", -1)
                    }["SortableRow[<IconButton>.onClick]"],
                    disabled: char.successes <= 0,
                    "aria-label": "Remove success",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RemoveRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            fontSize: 14
                        }
                    }, void 0, false, {
                        fileName: "[project]/packages/app/src/components/SortableRow.tsx",
                        lineNumber: 330,
                        columnNumber: 106
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/SortableRow.tsx",
                    lineNumber: 328,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    label: `${char.successes} / ${char.failures}`,
                    size: "small",
                    color: char.successes > char.failures ? "success" : char.failures > char.successes ? "error" : "default",
                    variant: "outlined",
                    "data-testid": `cy-initiative-saves-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTestId"])(char.name)}`,
                    sx: {
                        fontWeight: 700,
                        minWidth: 48
                    }
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/SortableRow.tsx",
                    lineNumber: 332,
                    columnNumber: 27
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    size: "small",
                    onClick: {
                        "SortableRow[<IconButton>.onClick]": ()=>onUpdateSaves(char.id, "failures", -1)
                    }["SortableRow[<IconButton>.onClick]"],
                    disabled: char.failures <= 0,
                    "aria-label": "Remove failure",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$RemoveRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sx: {
                            fontSize: 14
                        }
                    }, void 0, false, {
                        fileName: "[project]/packages/app/src/components/SortableRow.tsx",
                        lineNumber: 337,
                        columnNumber: 105
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/SortableRow.tsx",
                    lineNumber: 335,
                    columnNumber: 12
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    sx: {
                        flexGrow: 1
                    }
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/SortableRow.tsx",
                    lineNumber: 339,
                    columnNumber: 27
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    size: "small",
                    color: "success",
                    variant: "outlined",
                    onClick: {
                        "SortableRow[<Button>.onClick]": ()=>onUpdateSaves(char.id, "successes", 1)
                    }["SortableRow[<Button>.onClick]"],
                    disabled: char.successes >= 3,
                    sx: {
                        minWidth: 0,
                        px: 1,
                        fontSize: "0.7rem"
                    },
                    children: "Save"
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/SortableRow.tsx",
                    lineNumber: 341,
                    columnNumber: 12
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    size: "small",
                    color: "error",
                    variant: "outlined",
                    onClick: {
                        "SortableRow[<Button>.onClick]": ()=>onUpdateSaves(char.id, "failures", 1)
                    }["SortableRow[<Button>.onClick]"],
                    disabled: char.failures >= 3,
                    sx: {
                        minWidth: 0,
                        px: 1,
                        fontSize: "0.7rem"
                    },
                    children: "Fail"
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/SortableRow.tsx",
                    lineNumber: 347,
                    columnNumber: 23
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/SortableRow.tsx",
            lineNumber: 324,
            columnNumber: 70
        }, this);
        $[68] = char.dying;
        $[69] = char.failures;
        $[70] = char.id;
        $[71] = char.name;
        $[72] = char.successes;
        $[73] = isMonster;
        $[74] = isSkipped;
        $[75] = isStabilized;
        $[76] = onUpdateSaves;
        $[77] = t32;
    } else {
        t32 = $[77];
    }
    let t33;
    if ($[78] !== isStabilized) {
        t33 = isStabilized && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "success.main",
            sx: {
                width: "100%",
                pl: 3.5
            },
            children: "Stabilized"
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/SortableRow.tsx",
            lineNumber: 369,
            columnNumber: 27
        }, this);
        $[78] = isStabilized;
        $[79] = t33;
    } else {
        t33 = $[79];
    }
    let t34;
    if ($[80] !== isMonster || $[81] !== isSkipped) {
        t34 = isSkipped && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "caption",
            color: "error.main",
            sx: {
                width: "100%",
                pl: 3.5
            },
            children: isMonster ? "Defeated" : "Dead"
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/SortableRow.tsx",
            lineNumber: 380,
            columnNumber: 24
        }, this);
        $[80] = isMonster;
        $[81] = isSkipped;
        $[82] = t34;
    } else {
        t34 = $[82];
    }
    let t35;
    if ($[83] !== setNodeRef || $[84] !== style || $[85] !== t13 || $[86] !== t16 || $[87] !== t21 || $[88] !== t22 || $[89] !== t23 || $[90] !== t25 || $[91] !== t26 || $[92] !== t31 || $[93] !== t32 || $[94] !== t33 || $[95] !== t34 || $[96] !== t7 || $[97] !== t8 || $[98] !== t9) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            ref: setNodeRef,
            style: style,
            "data-testid": t7,
            "data-active": t8,
            "data-state": t9,
            direction: "row",
            alignItems: "center",
            spacing: 1,
            sx: t13,
            children: [
                t16,
                t21,
                t22,
                t23,
                t25,
                t26,
                t31,
                t32,
                t33,
                t34
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/SortableRow.tsx",
            lineNumber: 392,
            columnNumber: 11
        }, this);
        $[83] = setNodeRef;
        $[84] = style;
        $[85] = t13;
        $[86] = t16;
        $[87] = t21;
        $[88] = t22;
        $[89] = t23;
        $[90] = t25;
        $[91] = t26;
        $[92] = t31;
        $[93] = t32;
        $[94] = t33;
        $[95] = t34;
        $[96] = t7;
        $[97] = t8;
        $[98] = t9;
        $[99] = t35;
    } else {
        t35 = $[99];
    }
    return t35;
}
_s(SortableRow, "9J/a3p2iAf7PAeqkD/B/H2PQwgk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSortable"]
    ];
});
_c = SortableRow;
var _c;
__turbopack_context__.k.register(_c, "SortableRow");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/InitiativeTracker.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>InitiativeTracker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dnd-kit/core/dist/core.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@dnd-kit/sortable/dist/sortable.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AddRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/AddRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronLeftRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ChevronLeftRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronRightRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ChevronRightRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloseRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CloseRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PetsRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/PetsRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Alert/Alert.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Button/Button.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Menu/Menu.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/MenuItem/MenuItem.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/TextField/TextField.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/useGameStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/lib/initiative.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$SortableRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/SortableRow.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function InitiativeTracker() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(98);
    if ($[0] !== "127ee750124cf1b5e771ab91ced3e6e6bd1b8597726e626b7967100ea148fecb") {
        for(let $i = 0; $i < 98; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "127ee750124cf1b5e771ab91ced3e6e6bd1b8597726e626b7967100ea148fecb";
    }
    const characters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore);
    const resolved = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore2);
    const isReady = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore3);
    const activeIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore4);
    const round = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore5);
    const totalTurns = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore6);
    const queuedSetupCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore7);
    const monsters = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore8);
    const addCharacter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore9);
    const addMonster = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore10);
    const updateCharacter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore11);
    const deleteCharacter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore12);
    const ready = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore13);
    const reset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore14);
    const nextTurn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore15);
    const previousTurn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore16);
    const toggleDying = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore17);
    const setHp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore18);
    const updateSaves = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore19);
    const reorder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore20);
    const clearQueuedSetupCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_InitiativeTrackerUseGameStore21);
    const [newName, setNewName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [newBonus, setNewBonus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [monsterMenuAnchor, setMonsterMenuAnchor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const nameInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const listRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const shouldRefocusNameInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    let t0;
    if ($[1] !== addCharacter || $[2] !== newBonus || $[3] !== newName) {
        t0 = ({
            "InitiativeTracker[handleAddCharacter]": ()=>{
                addCharacter(newName, newBonus === "" ? 0 : Number(newBonus));
                setNewName("");
                setNewBonus("");
                nameInputRef.current?.focus();
            }
        })["InitiativeTracker[handleAddCharacter]"];
        $[1] = addCharacter;
        $[2] = newBonus;
        $[3] = newName;
        $[4] = t0;
    } else {
        t0 = $[4];
    }
    const handleAddCharacter = t0;
    const handleAddMonster = {
        "InitiativeTracker[handleAddMonster]": (slug)=>{
            addMonster(slug);
            shouldRefocusNameInputRef.current = true;
            setMonsterMenuAnchor(null);
        }
    }["InitiativeTracker[handleAddMonster]"];
    let t1;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "InitiativeTracker[handleMonsterMenuExited]": ()=>{
                if (!shouldRefocusNameInputRef.current) {
                    return;
                }
                shouldRefocusNameInputRef.current = false;
                nameInputRef.current?.focus();
            }
        })["InitiativeTracker[handleMonsterMenuExited]"];
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    const handleMonsterMenuExited = t1;
    let t2;
    if ($[6] !== reorder) {
        t2 = ({
            "InitiativeTracker[handleDragEnd]": (event)=>{
                const { active, over } = event;
                if (over && active.id !== over.id) {
                    reorder(String(active.id), String(over.id));
                }
            }
        })["InitiativeTracker[handleDragEnd]"];
        $[6] = reorder;
        $[7] = t2;
    } else {
        t2 = $[7];
    }
    const handleDragEnd = t2;
    const handleColumnTab = {
        "InitiativeTracker[handleColumnTab]": (e, col, index)=>{
            if (e.key !== "Tab" || e.shiftKey) {
                return;
            }
            const container = listRef.current;
            if (!container) {
                return;
            }
            const nextInCol = container.querySelector(`[data-col="${col}"][data-row="${index + 1}"]`);
            if (nextInCol) {
                e.preventDefault();
                nextInCol.focus();
                return;
            }
            const nextCol = col === "bonus" ? "roll" : null;
            if (nextCol) {
                const first = container.querySelector(`[data-col="${nextCol}"][data-row="0"]`);
                if (first) {
                    e.preventDefault();
                    first.focus();
                }
            }
        }
    }["InitiativeTracker[handleColumnTab]"];
    let t3;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            coordinateGetter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sortableKeyboardCoordinates"]
        };
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    const sensors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSensors"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSensor"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointerSensor"]), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSensor"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["KeyboardSensor"], t3));
    if (isReady) {
        let t4;
        if ($[9] !== totalTurns) {
            t4 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatTime"])(totalTurns);
            $[9] = totalTurns;
            $[10] = t4;
        } else {
            t4 = $[10];
        }
        let t5;
        if ($[11] !== round || $[12] !== t4) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "subtitle2",
                    color: "text.secondary",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "data-testid": "cy-initiative-round-status",
                        children: [
                            "Round ",
                            round,
                            " · ",
                            t4
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                        lineNumber: 166,
                        columnNumber: 74
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                    lineNumber: 166,
                    columnNumber: 19
                }, this)
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                lineNumber: 166,
                columnNumber: 12
            }, this);
            $[11] = round;
            $[12] = t4;
            $[13] = t5;
        } else {
            t5 = $[13];
        }
        let t6;
        if ($[14] !== reset) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                size: "small",
                onClick: reset,
                "data-testid": "cy-initiative-reset-button",
                children: "Reset"
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                lineNumber: 175,
                columnNumber: 12
            }, this);
            $[14] = reset;
            $[15] = t6;
        } else {
            t6 = $[15];
        }
        let t7;
        if ($[16] !== t5 || $[17] !== t6) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                direction: "row",
                justifyContent: "space-between",
                alignItems: "center",
                children: [
                    t5,
                    t6
                ]
            }, void 0, true, {
                fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                lineNumber: 183,
                columnNumber: 12
            }, this);
            $[16] = t5;
            $[17] = t6;
            $[18] = t7;
        } else {
            t7 = $[18];
        }
        let t8;
        if ($[19] !== clearQueuedSetupCount || $[20] !== queuedSetupCount) {
            t8 = queuedSetupCount > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Alert$2f$Alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                severity: "info",
                "data-testid": "cy-initiative-queued-setup-alert",
                onClose: clearQueuedSetupCount,
                children: [
                    queuedSetupCount,
                    " monster",
                    queuedSetupCount === 1 ? " was" : "s were",
                    " added to setup. Reset the tracker to include ",
                    queuedSetupCount === 1 ? "it" : "them",
                    " in the turn order."
                ]
            }, void 0, true, {
                fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                lineNumber: 192,
                columnNumber: 35
            }, this) : null;
            $[19] = clearQueuedSetupCount;
            $[20] = queuedSetupCount;
            $[21] = t8;
        } else {
            t8 = $[21];
        }
        let t9;
        if ($[22] !== resolved) {
            t9 = resolved.map(_InitiativeTrackerResolvedMap);
            $[22] = resolved;
            $[23] = t9;
        } else {
            t9 = $[23];
        }
        let t10;
        if ($[24] !== activeIndex || $[25] !== deleteCharacter || $[26] !== resolved || $[27] !== setHp || $[28] !== toggleDying || $[29] !== updateSaves) {
            let t11;
            if ($[31] !== activeIndex || $[32] !== deleteCharacter || $[33] !== setHp || $[34] !== toggleDying || $[35] !== updateSaves) {
                t11 = ({
                    "InitiativeTracker[resolved.map()]": (char, index_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$SortableRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            char: char,
                            isActive: index_0 === activeIndex,
                            onDelete: deleteCharacter,
                            onToggleDying: toggleDying,
                            onSetHp: setHp,
                            onUpdateSaves: updateSaves
                        }, char.id, false, {
                            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                            lineNumber: 212,
                            columnNumber: 67
                        }, this)
                })["InitiativeTracker[resolved.map()]"];
                $[31] = activeIndex;
                $[32] = deleteCharacter;
                $[33] = setHp;
                $[34] = toggleDying;
                $[35] = updateSaves;
                $[36] = t11;
            } else {
                t11 = $[36];
            }
            t10 = resolved.map(t11);
            $[24] = activeIndex;
            $[25] = deleteCharacter;
            $[26] = resolved;
            $[27] = setHp;
            $[28] = toggleDying;
            $[29] = updateSaves;
            $[30] = t10;
        } else {
            t10 = $[30];
        }
        let t11;
        if ($[37] !== t10 || $[38] !== t9) {
            t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SortableContext"], {
                items: t9,
                strategy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["verticalListSortingStrategy"],
                children: t10
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                lineNumber: 236,
                columnNumber: 13
            }, this);
            $[37] = t10;
            $[38] = t9;
            $[39] = t11;
        } else {
            t11 = $[39];
        }
        let t12;
        if ($[40] !== handleDragEnd || $[41] !== sensors || $[42] !== t11) {
            t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DndContext"], {
                sensors: sensors,
                collisionDetection: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["closestCenter"],
                onDragEnd: handleDragEnd,
                children: t11
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                lineNumber: 245,
                columnNumber: 13
            }, this);
            $[40] = handleDragEnd;
            $[41] = sensors;
            $[42] = t11;
            $[43] = t12;
        } else {
            t12 = $[43];
        }
        let t13;
        if ($[44] !== resolved.length) {
            t13 = resolved.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                color: "text.secondary",
                variant: "body2",
                children: "All characters removed."
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                lineNumber: 255,
                columnNumber: 38
            }, this);
            $[44] = resolved.length;
            $[45] = t13;
        } else {
            t13 = $[45];
        }
        let t14;
        if ($[46] !== activeIndex || $[47] !== nextTurn || $[48] !== previousTurn || $[49] !== resolved.length) {
            t14 = resolved.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                direction: "row",
                justifyContent: "center",
                alignItems: "center",
                spacing: 2,
                sx: {
                    pt: 1,
                    borderTop: 1,
                    borderColor: "divider"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        onClick: previousTurn,
                        "aria-label": "Previous turn",
                        "data-testid": "cy-initiative-previous-turn",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronLeftRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                            lineNumber: 267,
                            columnNumber: 114
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                        lineNumber: 267,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        variant: "body2",
                        color: "text.secondary",
                        "data-testid": "cy-initiative-turn-status",
                        children: [
                            "Turn ",
                            activeIndex + 1,
                            " / ",
                            resolved.length
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                        lineNumber: 267,
                        columnNumber: 153
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        onClick: nextTurn,
                        "aria-label": "Next turn",
                        "data-testid": "cy-initiative-next-turn",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronRightRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                            lineNumber: 267,
                            columnNumber: 391
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                        lineNumber: 267,
                        columnNumber: 299
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                lineNumber: 263,
                columnNumber: 36
            }, this);
            $[46] = activeIndex;
            $[47] = nextTurn;
            $[48] = previousTurn;
            $[49] = resolved.length;
            $[50] = t14;
        } else {
            t14 = $[50];
        }
        let t15;
        if ($[51] !== t12 || $[52] !== t13 || $[53] !== t14 || $[54] !== t7 || $[55] !== t8) {
            t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                spacing: 1.5,
                children: [
                    t7,
                    t8,
                    t12,
                    t13,
                    t14
                ]
            }, void 0, true, {
                fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                lineNumber: 278,
                columnNumber: 13
            }, this);
            $[51] = t12;
            $[52] = t13;
            $[53] = t14;
            $[54] = t7;
            $[55] = t8;
            $[56] = t15;
        } else {
            t15 = $[56];
        }
        return t15;
    }
    const T0 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
    const t4 = 2;
    let t5;
    if ($[57] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = ({
            "InitiativeTracker[<TextField>.onChange]": (e_0)=>setNewName(e_0.target.value)
        })["InitiativeTracker[<TextField>.onChange]"];
        $[57] = t5;
    } else {
        t5 = $[57];
    }
    let t6;
    if ($[58] !== handleAddCharacter) {
        t6 = ({
            "InitiativeTracker[<TextField>.onKeyDown]": (e_1)=>{
                if (e_1.key === "Enter") {
                    handleAddCharacter();
                }
            }
        })["InitiativeTracker[<TextField>.onKeyDown]"];
        $[58] = handleAddCharacter;
        $[59] = t6;
    } else {
        t6 = $[59];
    }
    let t7;
    let t8;
    if ($[60] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            htmlInput: {
                "data-testid": "cy-initiative-name-input"
            }
        };
        t8 = {
            flex: 1
        };
        $[60] = t7;
        $[61] = t8;
    } else {
        t7 = $[60];
        t8 = $[61];
    }
    let t9;
    if ($[62] !== newName || $[63] !== t6) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            inputRef: nameInputRef,
            label: "Name",
            size: "small",
            value: newName,
            onChange: t5,
            onKeyDown: t6,
            slotProps: t7,
            sx: t8
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
            lineNumber: 334,
            columnNumber: 10
        }, this);
        $[62] = newName;
        $[63] = t6;
        $[64] = t9;
    } else {
        t9 = $[64];
    }
    let t10;
    if ($[65] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = ({
            "InitiativeTracker[<TextField>.onChange]": (e_2)=>setNewBonus(e_2.target.value)
        })["InitiativeTracker[<TextField>.onChange]"];
        $[65] = t10;
    } else {
        t10 = $[65];
    }
    let t11;
    if ($[66] !== handleAddCharacter) {
        t11 = ({
            "InitiativeTracker[<TextField>.onKeyDown]": (e_3)=>{
                if (e_3.key === "Enter") {
                    handleAddCharacter();
                }
            }
        })["InitiativeTracker[<TextField>.onKeyDown]"];
        $[66] = handleAddCharacter;
        $[67] = t11;
    } else {
        t11 = $[67];
    }
    let t12;
    let t13;
    if ($[68] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = {
            htmlInput: {
                "data-testid": "cy-initiative-bonus-input"
            }
        };
        t13 = {
            width: 72
        };
        $[68] = t12;
        $[69] = t13;
    } else {
        t12 = $[68];
        t13 = $[69];
    }
    let t14;
    if ($[70] !== newBonus || $[71] !== t11) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "Bonus",
            size: "small",
            type: "number",
            value: newBonus,
            onChange: t10,
            onKeyDown: t11,
            slotProps: t12,
            sx: t13
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
            lineNumber: 383,
            columnNumber: 11
        }, this);
        $[70] = newBonus;
        $[71] = t11;
        $[72] = t14;
    } else {
        t14 = $[72];
    }
    let t15;
    if ($[73] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AddRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
            lineNumber: 392,
            columnNumber: 11
        }, this);
        $[73] = t15;
    } else {
        t15 = $[73];
    }
    let t16;
    if ($[74] !== handleAddCharacter) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: handleAddCharacter,
            color: "primary",
            "aria-label": "Add character",
            "data-testid": "cy-initiative-add-character",
            children: t15
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
            lineNumber: 399,
            columnNumber: 11
        }, this);
        $[74] = handleAddCharacter;
        $[75] = t16;
    } else {
        t16 = $[75];
    }
    let t17;
    if ($[76] !== monsters.length) {
        t17 = monsters.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: {
                "InitiativeTracker[<IconButton>.onClick]": (e_4)=>setMonsterMenuAnchor(e_4.currentTarget)
            }["InitiativeTracker[<IconButton>.onClick]"],
            color: "secondary",
            "aria-label": "Add monster",
            "data-testid": "cy-initiative-add-monster",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$PetsRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                lineNumber: 409,
                columnNumber: 134
            }, this)
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
            lineNumber: 407,
            columnNumber: 33
        }, this) : null;
        $[76] = monsters.length;
        $[77] = t17;
    } else {
        t17 = $[77];
    }
    let t18;
    if ($[78] !== t14 || $[79] !== t16 || $[80] !== t17 || $[81] !== t9) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            direction: "row",
            spacing: 1,
            alignItems: "flex-end",
            children: [
                t9,
                t14,
                t16,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
            lineNumber: 417,
            columnNumber: 11
        }, this);
        $[78] = t14;
        $[79] = t16;
        $[80] = t17;
        $[81] = t9;
        $[82] = t18;
    } else {
        t18 = $[82];
    }
    const t19 = Boolean(monsterMenuAnchor);
    let t20;
    if ($[83] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = ({
            "InitiativeTracker[<Menu>.onClose]": ()=>setMonsterMenuAnchor(null)
        })["InitiativeTracker[<Menu>.onClose]"];
        $[83] = t20;
    } else {
        t20 = $[83];
    }
    let t21;
    if ($[84] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = {
            transition: {
                onExited: handleMonsterMenuExited
            }
        };
        $[84] = t21;
    } else {
        t21 = $[84];
    }
    const t22 = monsters.map({
        "InitiativeTracker[monsters.map()]": (monster)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$MenuItem$2f$MenuItem$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                onClick: {
                    "InitiativeTracker[monsters.map() > <MenuItem>.onClick]": ()=>handleAddMonster(monster.slug)
                }["InitiativeTracker[monsters.map() > <MenuItem>.onClick]"],
                "data-testid": `cy-initiative-monster-option-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTestId"])(monster.name)}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    spacing: 0.25,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "body2",
                            fontWeight: 700,
                            children: monster.name
                        }, void 0, false, {
                            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                            lineNumber: 450,
                            columnNumber: 159
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "caption",
                            color: "text.secondary",
                            children: [
                                "Bonus ",
                                monster.dexModifier >= 0 ? `+${monster.dexModifier}` : monster.dexModifier,
                                " · HP ",
                                monster.hp
                            ]
                        }, void 0, true, {
                            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                            lineNumber: 450,
                            columnNumber: 231
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                    lineNumber: 450,
                    columnNumber: 137
                }, this)
            }, monster.slug, false, {
                fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                lineNumber: 448,
                columnNumber: 53
            }, this)
    }["InitiativeTracker[monsters.map()]"]);
    let t23;
    if ($[85] !== monsterMenuAnchor || $[86] !== t19 || $[87] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Menu$2f$Menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            anchorEl: monsterMenuAnchor,
            open: t19,
            onClose: t20,
            disableRestoreFocus: true,
            slotProps: t21,
            children: t22
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
            lineNumber: 454,
            columnNumber: 11
        }, this);
        $[85] = monsterMenuAnchor;
        $[86] = t19;
        $[87] = t22;
        $[88] = t23;
    } else {
        t23 = $[88];
    }
    const t24 = characters.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        spacing: 1,
        ref: listRef,
        children: characters.map({
            "InitiativeTracker[characters.map()]": (char_0, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    "data-testid": `cy-initiative-setup-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTestId"])(char_0.name)}`,
                    direction: "row",
                    spacing: 1,
                    alignItems: "center",
                    sx: {
                        px: 1
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            "data-testid": `cy-initiative-setup-name-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTestId"])(char_0.name)}`,
                            title: char_0.copyIndex != null ? char_0.name.replace(/ \d+$/, "") : char_0.name,
                            sx: {
                                flex: 1,
                                fontSize: "0.875rem",
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                                whiteSpace: "nowrap",
                                minWidth: 0
                            },
                            children: char_0.copyIndex != null ? char_0.name.replace(/ \d+$/, "") : char_0.name
                        }, void 0, false, {
                            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                            lineNumber: 465,
                            columnNumber: 10
                        }, this),
                        char_0.copyIndex != null ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            label: `#${char_0.copyIndex}`,
                            size: "small",
                            variant: "outlined",
                            sx: {
                                fontWeight: 700
                            }
                        }, void 0, false, {
                            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                            lineNumber: 472,
                            columnNumber: 128
                        }, this) : null,
                        typeof char_0.maxHp === "number" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            label: `HP ${char_0.maxHp}`,
                            size: "small",
                            color: "secondary",
                            variant: "outlined",
                            "data-testid": `cy-initiative-setup-hp-${(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$lib$2f$initiative$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTestId"])(char_0.name)}`
                        }, void 0, false, {
                            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                            lineNumber: 474,
                            columnNumber: 58
                        }, this) : null,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            size: "small",
                            type: "number",
                            placeholder: "Bonus",
                            value: char_0.bonus === 0 ? "" : char_0.bonus,
                            onChange: {
                                "InitiativeTracker[characters.map() > <TextField>.onChange]": (e_5)=>updateCharacter(char_0.id, "bonus", e_5.target.value)
                            }["InitiativeTracker[characters.map() > <TextField>.onChange]"],
                            onKeyDown: {
                                "InitiativeTracker[characters.map() > <TextField>.onKeyDown]": (e_6)=>handleColumnTab(e_6, "bonus", idx)
                            }["InitiativeTracker[characters.map() > <TextField>.onKeyDown]"],
                            sx: {
                                width: 64
                            },
                            slotProps: {
                                htmlInput: {
                                    "data-col": "bonus",
                                    "data-row": idx,
                                    "aria-label": `${char_0.name} bonus`
                                }
                            }
                        }, void 0, false, {
                            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                            lineNumber: 474,
                            columnNumber: 217
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$TextField$2f$TextField$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            size: "small",
                            type: "number",
                            placeholder: "Roll",
                            value: char_0.roll,
                            onChange: {
                                "InitiativeTracker[characters.map() > <TextField>.onChange]": (e_7)=>updateCharacter(char_0.id, "roll", e_7.target.value)
                            }["InitiativeTracker[characters.map() > <TextField>.onChange]"],
                            onKeyDown: {
                                "InitiativeTracker[characters.map() > <TextField>.onKeyDown]": (e_8)=>handleColumnTab(e_8, "roll", idx)
                            }["InitiativeTracker[characters.map() > <TextField>.onKeyDown]"],
                            sx: {
                                width: 64
                            },
                            slotProps: {
                                htmlInput: {
                                    "data-col": "roll",
                                    "data-row": idx,
                                    "aria-label": `${char_0.name} roll`
                                }
                            }
                        }, void 0, false, {
                            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                            lineNumber: 486,
                            columnNumber: 14
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            size: "small",
                            onClick: {
                                "InitiativeTracker[characters.map() > <IconButton>.onClick]": ()=>deleteCharacter(char_0.id)
                            }["InitiativeTracker[characters.map() > <IconButton>.onClick]"],
                            "aria-label": `Remove ${char_0.name}`,
                            tabIndex: -1,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CloseRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                fontSize: "small"
                            }, void 0, false, {
                                fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                                lineNumber: 500,
                                columnNumber: 125
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                            lineNumber: 498,
                            columnNumber: 14
                        }, this)
                    ]
                }, char_0.id, true, {
                    fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
                    lineNumber: 463,
                    columnNumber: 63
                }, this)
        }["InitiativeTracker[characters.map()]"])
    }, void 0, false, {
        fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
        lineNumber: 462,
        columnNumber: 40
    }, this);
    let t25;
    if ($[89] !== characters.length || $[90] !== ready) {
        t25 = characters.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Button$2f$Button$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "contained",
            onClick: ready,
            fullWidth: true,
            "data-testid": "cy-initiative-ready-button",
            children: "Ready"
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
            lineNumber: 504,
            columnNumber: 36
        }, this);
        $[89] = characters.length;
        $[90] = ready;
        $[91] = t25;
    } else {
        t25 = $[91];
    }
    let t26;
    if ($[92] !== T0 || $[93] !== t18 || $[94] !== t23 || $[95] !== t24 || $[96] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            spacing: t4,
            children: [
                t18,
                t23,
                t24,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/InitiativeTracker.tsx",
            lineNumber: 513,
            columnNumber: 11
        }, this);
        $[92] = T0;
        $[93] = t18;
        $[94] = t23;
        $[95] = t24;
        $[96] = t25;
        $[97] = t26;
    } else {
        t26 = $[97];
    }
    return t26;
}
_s(InitiativeTracker, "8r3pYjnaZzGBuhKAk60GWt8Yf48=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSensors"]
    ];
});
_c = InitiativeTracker;
function _InitiativeTrackerResolvedMap(c) {
    return c.id;
}
function _InitiativeTrackerUseGameStore21(s_19) {
    return s_19.clearQueuedSetupCount;
}
function _InitiativeTrackerUseGameStore20(s_18) {
    return s_18.reorder;
}
function _InitiativeTrackerUseGameStore19(s_17) {
    return s_17.updateSaves;
}
function _InitiativeTrackerUseGameStore18(s_16) {
    return s_16.setHp;
}
function _InitiativeTrackerUseGameStore17(s_15) {
    return s_15.toggleDying;
}
function _InitiativeTrackerUseGameStore16(s_14) {
    return s_14.previousTurn;
}
function _InitiativeTrackerUseGameStore15(s_13) {
    return s_13.nextTurn;
}
function _InitiativeTrackerUseGameStore14(s_12) {
    return s_12.reset;
}
function _InitiativeTrackerUseGameStore13(s_11) {
    return s_11.ready;
}
function _InitiativeTrackerUseGameStore12(s_10) {
    return s_10.deleteCharacter;
}
function _InitiativeTrackerUseGameStore11(s_9) {
    return s_9.updateCharacter;
}
function _InitiativeTrackerUseGameStore10(s_8) {
    return s_8.addMonster;
}
function _InitiativeTrackerUseGameStore9(s_7) {
    return s_7.addCharacter;
}
function _InitiativeTrackerUseGameStore8(s_6) {
    return s_6.monsters;
}
function _InitiativeTrackerUseGameStore7(s_5) {
    return s_5.queuedSetupCount;
}
function _InitiativeTrackerUseGameStore6(s_4) {
    return s_4.totalTurns;
}
function _InitiativeTrackerUseGameStore5(s_3) {
    return s_3.round;
}
function _InitiativeTrackerUseGameStore4(s_2) {
    return s_2.activeIndex;
}
function _InitiativeTrackerUseGameStore3(s_1) {
    return s_1.isReady;
}
function _InitiativeTrackerUseGameStore2(s_0) {
    return s_0.resolved;
}
function _InitiativeTrackerUseGameStore(s) {
    return s.characters;
}
var _c;
__turbopack_context__.k.register(_c, "InitiativeTracker");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/IconCircle.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>IconCircle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
;
;
;
function IconCircle(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "2bd5deaf90ded7780b18fa2357b7cc34592334753cd2a6b883a64d3560d2350a") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "2bd5deaf90ded7780b18fa2357b7cc34592334753cd2a6b883a64d3560d2350a";
    }
    const { size: t1, children } = t0;
    const size = t1 === undefined ? 36 : t1;
    let t2;
    if ($[1] !== size) {
        t2 = {
            width: size,
            height: size,
            borderRadius: "50%",
            border: "1px solid",
            borderColor: "divider",
            display: "grid",
            placeItems: "center",
            flexShrink: 0,
            backgroundColor: _temp
        };
        $[1] = size;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    let t3;
    if ($[3] !== children || $[4] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t2,
            children: children
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/IconCircle.tsx",
            lineNumber: 41,
            columnNumber: 10
        }, this);
        $[3] = children;
        $[4] = t2;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    return t3;
}
_c = IconCircle;
function _temp(t) {
    return t.palette.mode === "dark" ? "rgba(143,140,255,0.06)" : `${t.palette.primary.main}0f`;
}
var _c;
__turbopack_context__.k.register(_c, "IconCircle");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/ToolCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ToolCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronRightRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ChevronRightRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/ListItemButton/ListItemButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$IconCircle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/IconCircle.tsx [app-client] (ecmascript)");
;
;
;
;
;
;
;
function ToolCard(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(20);
    if ($[0] !== "40293a8b42bebac802c78dc28a34dd476c61cbeff3b88071eb4da3d0230f30ac") {
        for(let $i = 0; $i < 20; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "40293a8b42bebac802c78dc28a34dd476c61cbeff3b88071eb4da3d0230f30ac";
    }
    const { icon: Icon, label, description, onClick, testId } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            fontSize: 18,
            color: "primary.main"
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== Icon) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$IconCircle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            size: 36,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                sx: t1
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/ToolCard.tsx",
                lineNumber: 42,
                columnNumber: 32
            }, this)
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/ToolCard.tsx",
            lineNumber: 42,
            columnNumber: 10
        }, this);
        $[2] = Icon;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            flex: 1,
            minWidth: 0
        };
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = {
            fontWeight: 600,
            color: "sidebar.text",
            mb: 0.25
        };
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    let t5;
    if ($[6] !== label) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            sx: t4,
            children: label
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/ToolCard.tsx",
            lineNumber: 71,
            columnNumber: 10
        }, this);
        $[6] = label;
        $[7] = t5;
    } else {
        t5 = $[7];
    }
    let t6;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            color: "sidebar.mutedText",
            fontSize: "0.8rem",
            lineHeight: 1.4
        };
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] !== description) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            variant: "body2",
            sx: t6,
            children: description
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/ToolCard.tsx",
            lineNumber: 90,
            columnNumber: 10
        }, this);
        $[9] = description;
        $[10] = t7;
    } else {
        t7 = $[10];
    }
    let t8;
    if ($[11] !== t5 || $[12] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t3,
            children: [
                t5,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/ToolCard.tsx",
            lineNumber: 98,
            columnNumber: 10
        }, this);
        $[11] = t5;
        $[12] = t7;
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    let t9;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ChevronRightRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: {
                fontSize: 18,
                color: "sidebar.mutedText",
                flexShrink: 0
            }
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/ToolCard.tsx",
            lineNumber: 107,
            columnNumber: 10
        }, this);
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== onClick || $[16] !== t2 || $[17] !== t8 || $[18] !== testId) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$ListItemButton$2f$ListItemButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: onClick,
            "data-testid": testId,
            sx: _ToolCardListItemButtonSx,
            children: [
                t2,
                t8,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/ToolCard.tsx",
            lineNumber: 118,
            columnNumber: 11
        }, this);
        $[15] = onClick;
        $[16] = t2;
        $[17] = t8;
        $[18] = testId;
        $[19] = t10;
    } else {
        t10 = $[19];
    }
    return t10;
}
_c = ToolCard;
function _ToolCardListItemButtonSx(t) {
    return {
        borderRadius: "10px",
        border: "1px solid",
        borderColor: "divider",
        p: 2,
        gap: 1.5,
        alignItems: "center",
        boxShadow: t.palette.chrome.shadow,
        "&:hover": {
            transform: "translateY(-1px)",
            boxShadow: t.palette.mode === "dark" ? "0 6px 18px rgba(0,0,0,0.55)" : "0 6px 18px rgba(0,0,0,0.08)",
            borderColor: t.palette.mode === "dark" ? "rgba(143,140,255,0.35)" : t.palette.primary.main
        }
    };
}
var _c;
__turbopack_context__.k.register(_c, "ToolCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/ToolsSidebar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ToolsSidebar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AddRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/AddRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ArrowBackRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/ArrowBackRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CasinoRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/icons-material/esm/CasinoRounded.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/IconButton/IconButton.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/List/List.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$InitiativeTracker$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/InitiativeTracker.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$PanelHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/PanelHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$StatusDot$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/StatusDot.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$ToolCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/ToolCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$CollapseButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/CollapseButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/useGameStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const toolRegistry = [
    {
        slug: "initiative",
        label: "Initiative",
        description: "Track turn order, rounds, death saves, and monster HP without leaving the encounter flow.",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$CasinoRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        component: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$InitiativeTracker$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    }
];
function ToolsSidebar(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(49);
    if ($[0] !== "01a7184835aa104f6096f8c7d2fa388c72d3975d80a9c4500edfd09a51f143ee") {
        for(let $i = 0; $i < 49; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "01a7184835aa104f6096f8c7d2fa388c72d3975d80a9c4500edfd09a51f143ee";
    }
    const { tool } = t0;
    const setToolsParam = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_ToolsSidebarUseGameStore);
    const closeTools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_ToolsSidebarUseGameStore2);
    let t1;
    if ($[1] !== tool) {
        t1 = toolRegistry.find({
            "ToolsSidebar[toolRegistry.find()]": (t2)=>{
                const { slug } = t2;
                return slug === tool;
            }
        }["ToolsSidebar[toolRegistry.find()]"]);
        $[1] = tool;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const activeTool = t1;
    let t2;
    if ($[3] !== setToolsParam) {
        t2 = ({
            "ToolsSidebar[navigate]": (toolValue)=>setToolsParam(toolValue)
        })["ToolsSidebar[navigate]"];
        $[3] = setToolsParam;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const navigate = t2;
    let t3;
    if ($[5] !== navigate) {
        t3 = ({
            "ToolsSidebar[goBack]": ()=>navigate("menu")
        })["ToolsSidebar[goBack]"];
        $[5] = navigate;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const goBack = t3;
    let t4;
    if ($[7] !== closeTools) {
        t4 = ({
            "ToolsSidebar[handleCollapse]": ()=>closeTools()
        })["ToolsSidebar[handleCollapse]"];
        $[7] = closeTools;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    const handleCollapse = t4;
    if (activeTool) {
        const ActiveTool = activeTool.component;
        let t5;
        if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
            t5 = {
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                mb: 1
            };
            $[9] = t5;
        } else {
            t5 = $[9];
        }
        let t6;
        if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = {
                display: "flex",
                alignItems: "center",
                gap: 1
            };
            $[10] = t6;
        } else {
            t6 = $[10];
        }
        let t7;
        let t8;
        if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
            t7 = {
                border: "1px solid",
                borderColor: "divider",
                color: "sidebar.text"
            };
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$ArrowBackRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
                lineNumber: 123,
                columnNumber: 12
            }, this);
            $[11] = t7;
            $[12] = t8;
        } else {
            t7 = $[11];
            t8 = $[12];
        }
        let t9;
        if ($[13] !== goBack) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$IconButton$2f$IconButton$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                size: "small",
                onClick: goBack,
                "aria-label": "Back to tools",
                "data-testid": "cy-tools-back-button",
                sx: t7,
                children: t8
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
                lineNumber: 132,
                columnNumber: 12
            }, this);
            $[13] = goBack;
            $[14] = t9;
        } else {
            t9 = $[14];
        }
        let t10;
        if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
            t10 = {
                fontSize: 11,
                fontWeight: 700,
                letterSpacing: "0.12em",
                textTransform: "uppercase",
                color: "sidebar.mutedText"
            };
            $[15] = t10;
        } else {
            t10 = $[15];
        }
        let t11;
        if ($[16] !== activeTool.label) {
            t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t10,
                children: activeTool.label
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
                lineNumber: 153,
                columnNumber: 13
            }, this);
            $[16] = activeTool.label;
            $[17] = t11;
        } else {
            t11 = $[17];
        }
        let t12;
        if ($[18] !== t11 || $[19] !== t9) {
            t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t6,
                children: [
                    t9,
                    t11
                ]
            }, void 0, true, {
                fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
                lineNumber: 161,
                columnNumber: 13
            }, this);
            $[18] = t11;
            $[19] = t9;
            $[20] = t12;
        } else {
            t12 = $[20];
        }
        let t13;
        if ($[21] !== handleCollapse) {
            t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$CollapseButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                direction: "right",
                onClick: handleCollapse,
                testId: "cy-tools-collapse-button"
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
                lineNumber: 170,
                columnNumber: 13
            }, this);
            $[21] = handleCollapse;
            $[22] = t13;
        } else {
            t13 = $[22];
        }
        let t14;
        if ($[23] !== t12 || $[24] !== t13) {
            t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t5,
                children: [
                    t12,
                    t13
                ]
            }, void 0, true, {
                fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
                lineNumber: 178,
                columnNumber: 13
            }, this);
            $[23] = t12;
            $[24] = t13;
            $[25] = t14;
        } else {
            t14 = $[25];
        }
        let t15;
        if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
            t15 = {
                mb: 2.5,
                color: "sidebar.mutedText",
                fontSize: "0.8rem"
            };
            $[26] = t15;
        } else {
            t15 = $[26];
        }
        let t16;
        if ($[27] !== activeTool.description) {
            t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                variant: "body2",
                sx: t15,
                children: activeTool.description
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
                lineNumber: 198,
                columnNumber: 13
            }, this);
            $[27] = activeTool.description;
            $[28] = t16;
        } else {
            t16 = $[28];
        }
        let t17;
        if ($[29] !== ActiveTool) {
            t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ActiveTool, {}, void 0, false, {
                fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
                lineNumber: 206,
                columnNumber: 13
            }, this);
            $[29] = ActiveTool;
            $[30] = t17;
        } else {
            t17 = $[30];
        }
        let t18;
        if ($[31] !== t14 || $[32] !== t16 || $[33] !== t17) {
            t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    t14,
                    t16,
                    t17
                ]
            }, void 0, true);
            $[31] = t14;
            $[32] = t16;
            $[33] = t17;
            $[34] = t18;
        } else {
            t18 = $[34];
        }
        return t18;
    }
    let t5;
    let t6;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            display: "flex",
            alignItems: "center",
            gap: 1
        };
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$StatusDot$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            label: "Session Active"
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
            lineNumber: 232,
            columnNumber: 10
        }, this);
        $[35] = t5;
        $[36] = t6;
    } else {
        t5 = $[35];
        t6 = $[36];
    }
    let t7;
    if ($[37] !== handleCollapse) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$PanelHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: "Session Tools",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: t5,
                children: [
                    t6,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$CollapseButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        direction: "right",
                        onClick: handleCollapse,
                        testId: "cy-tools-collapse-button"
                    }, void 0, false, {
                        fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
                        lineNumber: 241,
                        columnNumber: 62
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
                lineNumber: 241,
                columnNumber: 45
            }, this)
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
            lineNumber: 241,
            columnNumber: 10
        }, this);
        $[37] = handleCollapse;
        $[38] = t7;
    } else {
        t7 = $[38];
    }
    let t8;
    if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            display: "grid",
            gap: 1
        };
        $[39] = t8;
    } else {
        t8 = $[39];
    }
    let t9;
    if ($[40] !== navigate) {
        t9 = toolRegistry.map({
            "ToolsSidebar[toolRegistry.map()]": (t10)=>{
                const { slug: slug_0, label, description, icon } = t10;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$ToolCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    icon: icon,
                    label: label,
                    description: description,
                    onClick: {
                        "ToolsSidebar[toolRegistry.map() > <ToolCard>.onClick]": ()=>navigate(slug_0)
                    }["ToolsSidebar[toolRegistry.map() > <ToolCard>.onClick]"],
                    testId: `cy-tool-item-${slug_0}`
                }, slug_0, false, {
                    fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
                    lineNumber: 267,
                    columnNumber: 16
                }, this);
            }
        }["ToolsSidebar[toolRegistry.map()]"]);
        $[40] = navigate;
        $[41] = t9;
    } else {
        t9 = $[41];
    }
    let t10;
    if ($[42] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$List$2f$List$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            disablePadding: true,
            "data-testid": "cy-tools-menu",
            sx: t8,
            children: t9
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
            lineNumber: 279,
            columnNumber: 11
        }, this);
        $[42] = t9;
        $[43] = t10;
    } else {
        t10 = $[43];
    }
    let t11;
    if ($[44] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            mt: 1,
            p: 2,
            border: "1px dashed",
            borderColor: "divider",
            borderRadius: "10px",
            display: "flex",
            justifyContent: "center",
            cursor: "default",
            transition: "border-color 0.15s ease, background-color 0.15s ease",
            "&:hover": {
                borderColor: _temp,
                backgroundColor: _temp2
            }
        };
        $[44] = t11;
    } else {
        t11 = $[44];
    }
    let t12;
    if ($[45] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            sx: t11,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$icons$2d$material$2f$esm$2f$AddRounded$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                sx: {
                    color: "text.secondary"
                }
            }, void 0, false, {
                fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
                lineNumber: 308,
                columnNumber: 25
            }, this)
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/ToolsSidebar.tsx",
            lineNumber: 308,
            columnNumber: 11
        }, this);
        $[45] = t12;
    } else {
        t12 = $[45];
    }
    let t13;
    if ($[46] !== t10 || $[47] !== t7) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t7,
                t10,
                t12
            ]
        }, void 0, true);
        $[46] = t10;
        $[47] = t7;
        $[48] = t13;
    } else {
        t13 = $[48];
    }
    return t13;
}
_s(ToolsSidebar, "gH7aZSxkdTNpsdLLCziktyy+gVQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"]
    ];
});
_c = ToolsSidebar;
function _temp2(t_0) {
    return t_0.palette.mode === "dark" ? "rgba(143,140,255,0.04)" : "action.hover";
}
function _temp(t) {
    return t.palette.mode === "dark" ? "rgba(143,140,255,0.45)" : "primary.main";
}
function _ToolsSidebarUseGameStore2(s_0) {
    return s_0.closeTools;
}
function _ToolsSidebarUseGameStore(s) {
    return s.setToolsParam;
}
var _c;
__turbopack_context__.k.register(_c, "ToolsSidebar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/TreasureDetailDialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TreasureDetailDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Chip/Chip.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Stack/Stack.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Typography/Typography.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$OverlayDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/OverlayDialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/useGameStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function TreasureDetailDialog() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(8);
    if ($[0] !== "5575eaec7f095471cccaac802f303cab6e06b124bca43ad6da97e85a62d7ef1d") {
        for(let $i = 0; $i < 8; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "5575eaec7f095471cccaac802f303cab6e06b124bca43ad6da97e85a62d7ef1d";
    }
    const openTreasureSlug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_TreasureDetailDialogUseGameStore);
    const treasureDataMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_TreasureDetailDialogUseGameStore2);
    const closeTreasure = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_TreasureDetailDialogUseGameStore3);
    const treasure = openTreasureSlug ? treasureDataMap[openTreasureSlug] : null;
    const t0 = Boolean(treasure);
    const t1 = treasure?.name ?? "Treasure details";
    let t2;
    if ($[1] !== treasure) {
        t2 = treasure ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            spacing: 2,
            sx: {
                py: 1
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Stack$2f$Stack$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    direction: "row",
                    spacing: 1,
                    children: [
                        treasure.type ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            label: treasure.type,
                            color: "secondary",
                            size: "small",
                            sx: {
                                fontWeight: 700,
                                textTransform: "uppercase"
                            }
                        }, void 0, false, {
                            fileName: "[project]/packages/app/src/components/TreasureDetailDialog.tsx",
                            lineNumber: 27,
                            columnNumber: 60
                        }, this) : null,
                        treasure.value ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Chip$2f$Chip$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            label: treasure.value,
                            color: "success",
                            variant: "outlined",
                            size: "small",
                            sx: {
                                fontWeight: 700
                            }
                        }, void 0, false, {
                            fileName: "[project]/packages/app/src/components/TreasureDetailDialog.tsx",
                            lineNumber: 30,
                            columnNumber: 40
                        }, this) : null
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/app/src/components/TreasureDetailDialog.tsx",
                    lineNumber: 27,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Typography$2f$Typography$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: "body1",
                    sx: {
                        mt: 1,
                        whiteSpace: "pre-wrap"
                    },
                    children: treasure.description
                }, void 0, false, {
                    fileName: "[project]/packages/app/src/components/TreasureDetailDialog.tsx",
                    lineNumber: 32,
                    columnNumber: 30
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/TreasureDetailDialog.tsx",
            lineNumber: 25,
            columnNumber: 21
        }, this) : null;
        $[1] = treasure;
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    let t3;
    if ($[3] !== closeTreasure || $[4] !== t0 || $[5] !== t1 || $[6] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$OverlayDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: t0,
            onClose: closeTreasure,
            title: t1,
            testId: "cy-treasure-detail-dialog",
            maxWidth: "sm",
            children: t2
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/TreasureDetailDialog.tsx",
            lineNumber: 43,
            columnNumber: 10
        }, this);
        $[3] = closeTreasure;
        $[4] = t0;
        $[5] = t1;
        $[6] = t2;
        $[7] = t3;
    } else {
        t3 = $[7];
    }
    return t3;
}
_s(TreasureDetailDialog, "D2f0QtouNCenJLpA8bNCsK2Jgkc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"]
    ];
});
_c = TreasureDetailDialog;
function _TreasureDetailDialogUseGameStore3(s_1) {
    return s_1.closeTreasure;
}
function _TreasureDetailDialogUseGameStore2(s_0) {
    return s_0.treasureDataMap;
}
function _TreasureDetailDialogUseGameStore(s) {
    return s.openTreasureSlug;
}
var _c;
__turbopack_context__.k.register(_c, "TreasureDetailDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/AppShell.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AppShell
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Box/Box.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Drawer/Drawer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useMediaQuery$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/useMediaQuery/index.js [app-client] (ecmascript) <export default as useMediaQuery>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$MonsterStatBlockDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/MonsterStatBlockDialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$StoreHydrator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/StoreHydrator.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$AreaSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/AreaSidebar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$LeftRail$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/LeftRail.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$PanelColumn$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/PanelColumn.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$ToolsSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/ToolsSidebar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/useGameStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$urlSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/urlSync.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$TreasureDetailDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/components/TreasureDetailDialog.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function AppShell(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(61);
    if ($[0] !== "8ef30f955ead7b884d7a5b7d0b4fcc5fc694df6b3f9c7ec10c448336e1cc88c8") {
        for(let $i = 0; $i < 61; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8ef30f955ead7b884d7a5b7d0b4fcc5fc694df6b3f9c7ec10c448336e1cc88c8";
    }
    const { areas, monsters, monsterDataMap, treasures, treasureDataMap, children } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            defaultMatches: true
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const isDesktop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useMediaQuery$3e$__["useMediaQuery"])(_AppShellUseMediaQuery, t1);
    const isHydrated = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(_AppShellUseSyncExternalStoreArg, _AppShellUseSyncExternalStoreArg2, _AppShellUseSyncExternalStoreArg3);
    const areaSidebarOpen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_AppShellUseGameStore);
    const selectedAreaSlug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_AppShellUseGameStore2) ?? undefined;
    const toolsParam = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_AppShellUseGameStore3) ?? undefined;
    const closeAreaSidebar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_AppShellUseGameStore4);
    const closeTools = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_AppShellUseGameStore5);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    let t2;
    if ($[2] !== closeAreaSidebar || $[3] !== router || $[4] !== selectedAreaSlug || $[5] !== toolsParam) {
        t2 = ({
            "AppShell[handleCloseAreaSidebar]": ()=>{
                closeAreaSidebar();
                router.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$urlSync$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildUrlFromState"])({
                    areaSidebarOpen: false,
                    selectedAreaSlug: selectedAreaSlug ?? null,
                    toolsParam: toolsParam ?? null
                }));
            }
        })["AppShell[handleCloseAreaSidebar]"];
        $[2] = closeAreaSidebar;
        $[3] = router;
        $[4] = selectedAreaSlug;
        $[5] = toolsParam;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    const handleCloseAreaSidebar = t2;
    let t3;
    if ($[7] !== monsterDataMap || $[8] !== monsters || $[9] !== treasureDataMap || $[10] !== treasures) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$StoreHydrator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            monsters: monsters,
            monsterDataMap: monsterDataMap,
            treasures: treasures,
            treasureDataMap: treasureDataMap
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AppShell.tsx",
            lineNumber: 87,
            columnNumber: 10
        }, this);
        $[7] = monsterDataMap;
        $[8] = monsters;
        $[9] = treasureDataMap;
        $[10] = treasures;
        $[11] = t3;
    } else {
        t3 = $[11];
    }
    const t4 = isHydrated ? "true" : "false";
    let t5;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$LeftRail$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/packages/app/src/components/AppShell.tsx",
            lineNumber: 99,
            columnNumber: 10
        }, this);
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    let t6;
    if ($[13] !== areaSidebarOpen) {
        t6 = areaSidebarOpen ? {
            xs: "none",
            lg: "flex"
        } : "none";
        $[13] = areaSidebarOpen;
        $[14] = t6;
    } else {
        t6 = $[14];
    }
    let t7;
    if ($[15] !== t6) {
        t7 = {
            display: t6
        };
        $[15] = t6;
        $[16] = t7;
    } else {
        t7 = $[16];
    }
    let t8;
    if ($[17] !== areas || $[18] !== selectedAreaSlug) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$AreaSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            areas: areas,
            selectedSlug: selectedAreaSlug
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AppShell.tsx",
            lineNumber: 127,
            columnNumber: 10
        }, this);
        $[17] = areas;
        $[18] = selectedAreaSlug;
        $[19] = t8;
    } else {
        t8 = $[19];
    }
    let t9;
    if ($[20] !== t7 || $[21] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$PanelColumn$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            width: 320,
            side: "left",
            sx: t7,
            children: t8
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AppShell.tsx",
            lineNumber: 136,
            columnNumber: 10
        }, this);
        $[20] = t7;
        $[21] = t8;
        $[22] = t9;
    } else {
        t9 = $[22];
    }
    const t10 = !isDesktop && areaSidebarOpen;
    let t11;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            display: {
                xs: "block",
                lg: "none"
            },
            "& .MuiDrawer-paper": {
                ml: "72px",
                width: 320
            }
        };
        $[23] = t11;
    } else {
        t11 = $[23];
    }
    let t12;
    if ($[24] !== areas || $[25] !== selectedAreaSlug) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$AreaSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            areas: areas,
            selectedSlug: selectedAreaSlug
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AppShell.tsx",
            lineNumber: 162,
            columnNumber: 11
        }, this);
        $[24] = areas;
        $[25] = selectedAreaSlug;
        $[26] = t12;
    } else {
        t12 = $[26];
    }
    let t13;
    if ($[27] !== handleCloseAreaSidebar || $[28] !== t10 || $[29] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            anchor: "left",
            open: t10,
            onClose: handleCloseAreaSidebar,
            sx: t11,
            children: t12
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AppShell.tsx",
            lineNumber: 171,
            columnNumber: 11
        }, this);
        $[27] = handleCloseAreaSidebar;
        $[28] = t10;
        $[29] = t12;
        $[30] = t13;
    } else {
        t13 = $[30];
    }
    let t14;
    if ($[31] !== children) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Box$2f$Box$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            component: "main",
            className: "app-main",
            children: children
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AppShell.tsx",
            lineNumber: 181,
            columnNumber: 11
        }, this);
        $[31] = children;
        $[32] = t14;
    } else {
        t14 = $[32];
    }
    let t15;
    if ($[33] !== toolsParam) {
        t15 = toolsParam != null ? {
            xs: "none",
            lg: "flex"
        } : "none";
        $[33] = toolsParam;
        $[34] = t15;
    } else {
        t15 = $[34];
    }
    let t16;
    if ($[35] !== t15) {
        t16 = {
            display: t15,
            p: 2
        };
        $[35] = t15;
        $[36] = t16;
    } else {
        t16 = $[36];
    }
    const t17 = toolsParam ?? "menu";
    let t18;
    if ($[37] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$ToolsSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            tool: t17
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AppShell.tsx",
            lineNumber: 212,
            columnNumber: 11
        }, this);
        $[37] = t17;
        $[38] = t18;
    } else {
        t18 = $[38];
    }
    let t19;
    if ($[39] !== t16 || $[40] !== t18) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$PanelColumn$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            width: 300,
            side: "right",
            sx: t16,
            children: t18
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AppShell.tsx",
            lineNumber: 220,
            columnNumber: 11
        }, this);
        $[39] = t16;
        $[40] = t18;
        $[41] = t19;
    } else {
        t19 = $[41];
    }
    const t20 = !isDesktop && Boolean(toolsParam);
    let t21;
    if ($[42] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = {
            display: {
                xs: "block",
                lg: "none"
            },
            "& .MuiDrawer-paper": {
                width: 300
            }
        };
        $[42] = t21;
    } else {
        t21 = $[42];
    }
    const t22 = toolsParam ?? "menu";
    let t23;
    if ($[43] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$ToolsSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            tool: t22
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AppShell.tsx",
            lineNumber: 246,
            columnNumber: 11
        }, this);
        $[43] = t22;
        $[44] = t23;
    } else {
        t23 = $[44];
    }
    let t24;
    if ($[45] !== closeTools || $[46] !== t20 || $[47] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Drawer$2f$Drawer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            anchor: "right",
            open: t20,
            onClose: closeTools,
            sx: t21,
            children: t23
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/AppShell.tsx",
            lineNumber: 254,
            columnNumber: 11
        }, this);
        $[45] = closeTools;
        $[46] = t20;
        $[47] = t23;
        $[48] = t24;
    } else {
        t24 = $[48];
    }
    let t25;
    if ($[49] !== t13 || $[50] !== t14 || $[51] !== t19 || $[52] !== t24 || $[53] !== t4 || $[54] !== t9) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "app-shell",
            "data-testid": "cy-app-shell",
            "data-hydrated": t4,
            children: [
                t5,
                t9,
                t13,
                t14,
                t19,
                t24
            ]
        }, void 0, true, {
            fileName: "[project]/packages/app/src/components/AppShell.tsx",
            lineNumber: 264,
            columnNumber: 11
        }, this);
        $[49] = t13;
        $[50] = t14;
        $[51] = t19;
        $[52] = t24;
        $[53] = t4;
        $[54] = t9;
        $[55] = t25;
    } else {
        t25 = $[55];
    }
    let t26;
    let t27;
    if ($[56] === Symbol.for("react.memo_cache_sentinel")) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$MonsterStatBlockDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/packages/app/src/components/AppShell.tsx",
            lineNumber: 278,
            columnNumber: 11
        }, this);
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$components$2f$TreasureDetailDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/packages/app/src/components/AppShell.tsx",
            lineNumber: 279,
            columnNumber: 11
        }, this);
        $[56] = t26;
        $[57] = t27;
    } else {
        t26 = $[56];
        t27 = $[57];
    }
    let t28;
    if ($[58] !== t25 || $[59] !== t3) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t3,
                t25,
                t26,
                t27
            ]
        }, void 0, true);
        $[58] = t25;
        $[59] = t3;
        $[60] = t28;
    } else {
        t28 = $[60];
    }
    return t28;
}
_s(AppShell, "xLtMXFgOyA4Cs+GRTvjLke7oB7U=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$useMediaQuery$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__useMediaQuery$3e$__["useMediaQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = AppShell;
function _AppShellUseGameStore5(s_3) {
    return s_3.closeTools;
}
function _AppShellUseGameStore4(s_2) {
    return s_2.closeAreaSidebar;
}
function _AppShellUseGameStore3(s_1) {
    return s_1.toolsParam;
}
function _AppShellUseGameStore2(s_0) {
    return s_0.selectedAreaSlug;
}
function _AppShellUseGameStore(s) {
    return s.areaSidebarOpen;
}
function _AppShellUseSyncExternalStoreArg3() {
    return false;
}
function _AppShellUseSyncExternalStoreArg2() {
    return true;
}
function _AppShellUseSyncExternalStoreArg() {
    return _temp;
}
function _temp() {}
function _AppShellUseMediaQuery(theme) {
    return theme.breakpoints.up("lg");
}
var _c;
__turbopack_context__.k.register(_c, "AppShell");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/theme.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/system/esm/colorManipulator/colorManipulator.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$createTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createTheme$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/createTheme.js [app-client] (ecmascript) <export default as createTheme>");
;
// Light mode tokens
const parchmentTone = "#F4F1EA";
const surfaceWhite = "#FFFFFF";
const primaryText = "#2B2B2B";
const secondaryText = "#6B6B6B";
const indigoAccent = "#5C6BC0";
const goldAccent = "#C2A96A";
const subtleBorder = "#D8D2C4";
// Dark mode tokens
const darkBgMain = "#0d1016";
const darkBgSurface = "#151922";
const darkTextPrimary = "#ece8df";
const darkTextSecondary = "#aaa49a";
const darkTextMuted = "#7d776d";
const darkAccentPrimary = "#8f8cff";
const darkAccentGold = "#c4a76a";
const darkBorderSubtle = "rgba(196, 167, 106, 0.18)";
const darkBorderStrong = "rgba(196, 167, 106, 0.32)";
const headingStyles = {
    fontFamily: "var(--font-display), serif",
    fontWeight: 600,
    letterSpacing: "0.04em"
};
const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$createTheme$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__createTheme$3e$__["createTheme"])({
    cssVariables: {
        colorSchemeSelector: "class"
    },
    colorSchemes: {
        light: {
            palette: {
                mode: "light",
                primary: {
                    main: indigoAccent,
                    dark: "#3949AB",
                    light: "#7986CB",
                    contrastText: "#ffffff"
                },
                secondary: {
                    main: goldAccent,
                    dark: "#8D7540",
                    light: "#D4BC8A",
                    contrastText: "#2B2B2B"
                },
                background: {
                    default: parchmentTone,
                    paper: surfaceWhite
                },
                text: {
                    primary: primaryText,
                    secondary: secondaryText
                },
                divider: subtleBorder,
                success: {
                    main: "#4a744a"
                },
                warning: {
                    main: "#bd7a1a"
                },
                chrome: {
                    text: primaryText,
                    mutedText: secondaryText,
                    dimText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["alpha"])(primaryText, 0.48),
                    border: subtleBorder,
                    borderStrong: "#BFB9AF",
                    borderGlow: "none",
                    shadow: "0 4px 12px rgba(0,0,0,0.06)",
                    railBg: "transparent",
                    railBorder: subtleBorder,
                    railActiveMark: indigoAccent,
                    railActiveIcon: indigoAccent,
                    railActiveGlow: "none"
                },
                sidebar: {
                    background: surfaceWhite,
                    border: subtleBorder,
                    shadow: "0 4px 12px rgba(0,0,0,0.06)",
                    mutedText: secondaryText,
                    text: primaryText,
                    itemBg: "transparent",
                    itemBgActive: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["alpha"])(indigoAccent, 0.06),
                    itemBgActiveHover: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["alpha"])(indigoAccent, 0.10),
                    itemBorder: "transparent",
                    itemBorderActive: indigoAccent,
                    itemBorderHover: subtleBorder
                },
                hero: {
                    background: parchmentTone,
                    overlay: "none",
                    border: subtleBorder,
                    shadow: "0 4px 12px rgba(0,0,0,0.06)",
                    text: primaryText,
                    mutedText: secondaryText
                }
            }
        },
        dark: {
            palette: {
                mode: "dark",
                primary: {
                    main: darkAccentPrimary,
                    dark: "#5C5ACC",
                    light: "#B0AEFF",
                    contrastText: "#0d1016"
                },
                secondary: {
                    main: darkAccentGold,
                    dark: "#8A6F3A",
                    light: "#DBC083",
                    contrastText: "#0d1016"
                },
                background: {
                    default: darkBgMain,
                    paper: darkBgSurface
                },
                text: {
                    primary: darkTextPrimary,
                    secondary: darkTextSecondary
                },
                divider: darkBorderSubtle,
                success: {
                    main: "#78a886"
                },
                warning: {
                    main: "#e0a343"
                },
                chrome: {
                    text: darkTextPrimary,
                    mutedText: darkTextSecondary,
                    dimText: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["alpha"])(darkTextPrimary, 0.48),
                    border: darkBorderSubtle,
                    borderStrong: darkBorderStrong,
                    borderGlow: `linear-gradient(90deg, transparent, ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["alpha"])(darkAccentGold, 0.35)} 50%, transparent)`,
                    shadow: "0 18px 40px rgba(0,0,0,0.45)",
                    railBg: "transparent",
                    railBorder: darkBorderSubtle,
                    railActiveMark: darkAccentPrimary,
                    railActiveIcon: darkAccentPrimary,
                    railActiveGlow: "0 0 16px rgba(143,140,255,0.6)"
                },
                sidebar: {
                    background: `linear-gradient(180deg, rgba(27,32,43,0.96), rgba(16,19,27,0.96))`,
                    border: darkBorderSubtle,
                    shadow: "0 18px 40px rgba(0,0,0,0.45)",
                    mutedText: darkTextMuted,
                    text: darkTextPrimary,
                    itemBg: "transparent",
                    itemBgActive: "rgba(143,140,255,0.09)",
                    itemBgActiveHover: "rgba(143,140,255,0.13)",
                    itemBorder: "transparent",
                    itemBorderActive: darkAccentPrimary,
                    itemBorderHover: darkBorderSubtle
                },
                hero: {
                    background: `linear-gradient(180deg, ${darkBgSurface}, ${darkBgMain})`,
                    overlay: `radial-gradient(circle at 30% 0%, rgba(143,140,255,0.12), transparent 32%), radial-gradient(circle at 80% 20%, rgba(196,167,106,0.08), transparent 28%)`,
                    border: darkBorderSubtle,
                    shadow: "0 18px 40px rgba(0,0,0,0.45)",
                    text: darkTextPrimary,
                    mutedText: darkTextSecondary
                }
            }
        }
    },
    shape: {
        borderRadius: 12
    },
    typography: {
        fontFamily: "var(--font-body), sans-serif",
        h1: {
            ...headingStyles,
            fontSize: "3.5rem",
            lineHeight: 1.06
        },
        h2: {
            ...headingStyles,
            fontSize: "2.5rem",
            lineHeight: 1.1
        },
        h3: {
            ...headingStyles,
            fontSize: "1.7rem",
            lineHeight: 1.18
        },
        h6: {
            ...headingStyles,
            fontSize: "0.95rem",
            lineHeight: 1.2
        },
        body1: {
            fontSize: "1rem",
            lineHeight: 1.7
        },
        body2: {
            fontSize: "0.875rem",
            lineHeight: 1.6
        },
        button: {
            fontWeight: 600,
            letterSpacing: "0.04em",
            textTransform: "none"
        }
    },
    components: {
        MuiAppBar: {
            styleOverrides: {
                root: ({ theme: t })=>({
                        backgroundColor: t.palette.background.paper,
                        backgroundImage: "none",
                        borderBottom: `1px solid ${t.palette.divider}`,
                        boxShadow: t.palette.chrome.shadow
                    })
            }
        },
        MuiPaper: {
            styleOverrides: {
                root: {
                    backgroundImage: "none"
                }
            }
        },
        MuiButton: {
            styleOverrides: {
                root: {
                    borderRadius: 999,
                    boxShadow: "none",
                    paddingInline: "20px",
                    paddingBlock: "9px",
                    "&:hover": {
                        boxShadow: "none"
                    }
                },
                containedPrimary: ({ theme: t })=>({
                        backgroundColor: t.palette.primary.main,
                        "&:hover": {
                            backgroundColor: t.palette.primary.dark,
                            ...t.palette.mode === "dark" && {
                                boxShadow: "0 0 24px rgba(143,140,255,0.25)"
                            }
                        }
                    }),
                outlined: ({ theme: t })=>({
                        borderWidth: 1,
                        borderColor: t.palette.divider,
                        color: t.palette.text.primary,
                        "&:hover": {
                            borderColor: t.palette.primary.main,
                            backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["alpha"])(t.palette.primary.main, 0.06)
                        }
                    }),
                outlinedSuccess: ({ theme: t })=>({
                        borderColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["alpha"])(t.palette.success.main, 0.6),
                        color: t.palette.success.main,
                        "&:hover": {
                            borderColor: t.palette.success.main,
                            backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["alpha"])(t.palette.success.main, 0.1)
                        }
                    }),
                outlinedError: ({ theme: t })=>({
                        borderColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["alpha"])(t.palette.error.main, 0.6),
                        color: t.palette.error.main,
                        "&:hover": {
                            borderColor: t.palette.error.main,
                            backgroundColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$system$2f$esm$2f$colorManipulator$2f$colorManipulator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["alpha"])(t.palette.error.main, 0.1)
                        }
                    })
            }
        },
        MuiChip: {
            styleOverrides: {
                root: {
                    borderRadius: 999,
                    fontWeight: 600,
                    letterSpacing: "0.04em"
                }
            }
        },
        MuiOutlinedInput: {
            styleOverrides: {
                root: ({ theme: t })=>({
                        borderRadius: 10,
                        backgroundColor: t.palette.mode === "dark" ? "rgba(255,255,255,0.045)" : "transparent",
                        "& fieldset": {
                            borderColor: t.palette.divider
                        },
                        "&:hover fieldset": {
                            borderColor: t.palette.primary.main
                        },
                        "&.Mui-focused fieldset": {
                            borderColor: t.palette.primary.main,
                            borderWidth: 1.5
                        }
                    })
            }
        },
        MuiListItemButton: {
            styleOverrides: {
                root: ({ theme: t })=>({
                        transition: t.transitions.create([
                            "border-color",
                            "background-color",
                            "transform",
                            "box-shadow"
                        ], {
                            duration: 150
                        })
                    })
            }
        },
        MuiDivider: {
            styleOverrides: {
                root: ({ theme: t })=>({
                        borderColor: t.palette.divider
                    })
            }
        }
    }
});
const __TURBOPACK__default__export__ = theme;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/ThemeRegistry.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ThemeRegistry
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2d$nextjs$2f$esm$2f$v13$2d$appRouter$2f$appRouterV13$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AppRouterCacheProvider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material-nextjs/esm/v13-appRouter/appRouterV13.js [app-client] (ecmascript) <export default as AppRouterCacheProvider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CssBaseline$2f$CssBaseline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/CssBaseline/CssBaseline.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ThemeProvider$3e$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/styles/ThemeProvider.js [app-client] (ecmascript) <export default as ThemeProvider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$theme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/theme.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
function ThemeRegistry(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "205531ec4d1d783960aebb999fc6569b5cad709e1c110b1181630e5163abdeed") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "205531ec4d1d783960aebb999fc6569b5cad709e1c110b1181630e5163abdeed";
    }
    const { children } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$CssBaseline$2f$CssBaseline$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/packages/app/src/components/ThemeRegistry.tsx",
            lineNumber: 25,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== children) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2d$nextjs$2f$esm$2f$v13$2d$appRouter$2f$appRouterV13$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AppRouterCacheProvider$3e$__["AppRouterCacheProvider"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$styles$2f$ThemeProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ThemeProvider$3e$__["ThemeProvider"], {
                theme: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$theme$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                defaultMode: "system",
                disableTransitionOnChange: true,
                children: [
                    t1,
                    children
                ]
            }, void 0, true, {
                fileName: "[project]/packages/app/src/components/ThemeRegistry.tsx",
                lineNumber: 32,
                columnNumber: 34
            }, this)
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/ThemeRegistry.tsx",
            lineNumber: 32,
            columnNumber: 10
        }, this);
        $[2] = children;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    return t2;
}
_c = ThemeRegistry;
var _c;
__turbopack_context__.k.register(_c, "ThemeRegistry");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/MonsterReference.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MonsterReference
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Link$2f$Link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Link/Link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/useGameStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function MonsterReference(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(11);
    if ($[0] !== "4759e27ff953fc7787cb472e90fb9344a6a7cda0fcec7ebaa81580c4b9b23efd") {
        for(let $i = 0; $i < 11; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "4759e27ff953fc7787cb472e90fb9344a6a7cda0fcec7ebaa81580c4b9b23efd";
    }
    const { slug, children } = t0;
    const monsterDataMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_MonsterReferenceUseGameStore);
    const openStatBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_MonsterReferenceUseGameStore2);
    const monster = monsterDataMap[slug];
    if (!monster) {
        let t1;
        if ($[1] !== children) {
            t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: children
            }, void 0, false);
            $[1] = children;
            $[2] = t1;
        } else {
            t1 = $[2];
        }
        return t1;
    }
    let t1;
    if ($[3] !== openStatBlock || $[4] !== slug) {
        t1 = ({
            "MonsterReference[<Link>.onClick]": ()=>openStatBlock(slug)
        })["MonsterReference[<Link>.onClick]"];
        $[3] = openStatBlock;
        $[4] = slug;
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    const t2 = `cy-monster-reference-${slug}`;
    let t3;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            cursor: "pointer",
            fontWeight: 700,
            textAlign: "inherit"
        };
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const t4 = children ?? monster.name;
    let t5;
    if ($[7] !== t1 || $[8] !== t2 || $[9] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Link$2f$Link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            component: "button",
            type: "button",
            underline: "hover",
            color: "primary",
            onClick: t1,
            "data-testid": t2,
            sx: t3,
            children: t4
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/MonsterReference.tsx",
            lineNumber: 63,
            columnNumber: 10
        }, this);
        $[7] = t1;
        $[8] = t2;
        $[9] = t4;
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    return t5;
}
_s(MonsterReference, "8vmAll5sPrc3cow/eSoZ4+eFo7c=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"]
    ];
});
_c = MonsterReference;
function _MonsterReferenceUseGameStore2(s_0) {
    return s_0.openStatBlock;
}
function _MonsterReferenceUseGameStore(s) {
    return s.monsterDataMap;
}
var _c;
__turbopack_context__.k.register(_c, "MonsterReference");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/app/src/components/TreasureReference.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TreasureReference
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Link$2f$Link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@mui/material/esm/Link/Link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/app/src/store/useGameStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function TreasureReference(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(11);
    if ($[0] !== "8acdb33d9a80592474ba2f4c7796de61b69a030444b1e78c4d5241e46419b473") {
        for(let $i = 0; $i < 11; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8acdb33d9a80592474ba2f4c7796de61b69a030444b1e78c4d5241e46419b473";
    }
    const { slug, children } = t0;
    const treasureDataMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_TreasureReferenceUseGameStore);
    const openTreasure = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"])(_TreasureReferenceUseGameStore2);
    const treasure = treasureDataMap[slug];
    if (!treasure) {
        let t1;
        if ($[1] !== children) {
            t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: children
            }, void 0, false);
            $[1] = children;
            $[2] = t1;
        } else {
            t1 = $[2];
        }
        return t1;
    }
    let t1;
    if ($[3] !== openTreasure || $[4] !== slug) {
        t1 = ({
            "TreasureReference[<Link>.onClick]": ()=>openTreasure(slug)
        })["TreasureReference[<Link>.onClick]"];
        $[3] = openTreasure;
        $[4] = slug;
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    const t2 = `cy-treasure-reference-${slug}`;
    let t3;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            cursor: "pointer",
            fontWeight: 700,
            textAlign: "inherit"
        };
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const t4 = children ?? treasure.name;
    let t5;
    if ($[7] !== t1 || $[8] !== t2 || $[9] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$mui$2f$material$2f$esm$2f$Link$2f$Link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            component: "button",
            type: "button",
            underline: "hover",
            color: "primary",
            onClick: t1,
            "data-testid": t2,
            sx: t3,
            children: t4
        }, void 0, false, {
            fileName: "[project]/packages/app/src/components/TreasureReference.tsx",
            lineNumber: 63,
            columnNumber: 10
        }, this);
        $[7] = t1;
        $[8] = t2;
        $[9] = t4;
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    return t5;
}
_s(TreasureReference, "Imdr9nk4ENz2QDAovX/mxaLVWlE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$app$2f$src$2f$store$2f$useGameStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGameStore"]
    ];
});
_c = TreasureReference;
function _TreasureReferenceUseGameStore2(s_0) {
    return s_0.openTreasure;
}
function _TreasureReferenceUseGameStore(s) {
    return s.treasureDataMap;
}
var _c;
__turbopack_context__.k.register(_c, "TreasureReference");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=packages_app_src_05epz.u._.js.map